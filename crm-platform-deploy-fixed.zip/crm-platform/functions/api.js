const mongoose = require('mongoose');

// Import models
const User = require('./models/User');
const Contact = require('./models/Contact');

// Import services
const HubSpotImportService = require('./services/hubspotImport');
const LinkedInImportService = require('./services/linkedinImport');
const GmailImportService = require('./services/gmailImport');

// Database connection
let cachedDb = null;

async function connectToDatabase() {
  if (cachedDb) {
    return cachedDb;
  }

  const connection = await mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });

  cachedDb = connection;
  return connection;
}

// Helper function to parse multipart form data
function parseMultipartData(body, boundary) {
  const parts = body.split(`--${boundary}`);
  const result = { fields: {}, files: {} };
  
  for (const part of parts) {
    if (part.includes('Content-Disposition')) {
      const lines = part.split('\r\n');
      const dispositionLine = lines.find(line => line.includes('Content-Disposition'));
      
      if (dispositionLine) {
        const nameMatch = dispositionLine.match(/name="([^"]+)"/);
        const filenameMatch = dispositionLine.match(/filename="([^"]+)"/);
        
        if (nameMatch) {
          const fieldName = nameMatch[1];
          const contentStartIndex = part.indexOf('\r\n\r\n') + 4;
          const content = part.substring(contentStartIndex).replace(/\r\n$/, '');
          
          if (filenameMatch) {
            result.files[fieldName] = {
              filename: filenameMatch[1],
              content: content
            };
          } else {
            result.fields[fieldName] = content;
          }
        }
      }
    }
  }
  
  return result;
}

exports.handler = async (event, context) => {
  // Enable CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    await connectToDatabase();
    
    const path = event.path.replace('/.netlify/functions/api', '');
    const method = event.httpMethod;
    
    // Health check
    if (path === '/health' && method === 'GET') {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ status: 'OK', timestamp: new Date().toISOString() })
      };
    }

    // Authentication routes
    if (path.startsWith('/auth')) {
      return await handleAuth(path, method, event, headers);
    }

    // Contact routes
    if (path.startsWith('/contacts')) {
      return await handleContacts(path, method, event, headers);
    }

    // Import routes
    if (path.startsWith('/import')) {
      return await handleImport(path, method, event, headers);
    }

    return {
      statusCode: 404,
      headers,
      body: JSON.stringify({ error: 'Route not found' })
    };

  } catch (error) {
    console.error('Function error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};

async function handleAuth(path, method, event, headers) {
  const bcrypt = require('bcryptjs');
  const jwt = require('jsonwebtoken');

  if (path === '/auth/register' && method === 'POST') {
    const { firstName, lastName, email, password } = JSON.parse(event.body);

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'User already exists' })
      };
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const user = new User({
      firstName,
      lastName,
      email,
      password: hashedPassword
    });

    await user.save();

    const token = jwt.sign(
      { userId: user._id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    return {
      statusCode: 201,
      headers,
      body: JSON.stringify({
        token,
        user: { id: user._id, firstName, lastName, email }
      })
    };
  }

  if (path === '/auth/login' && method === 'POST') {
    const { email, password } = JSON.parse(event.body);

    const user = await User.findOne({ email });
    if (!user) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Invalid credentials' })
      };
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Invalid credentials' })
      };
    }

    const token = jwt.sign(
      { userId: user._id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        token,
        user: { id: user._id, firstName: user.firstName, lastName: user.lastName, email: user.email }
      })
    };
  }

  return {
    statusCode: 404,
    headers,
    body: JSON.stringify({ error: 'Auth route not found' })
  };
}

async function handleContacts(path, method, event, headers) {
  const authHeader = event.headers.authorization;
  if (!authHeader) {
    return {
      statusCode: 401,
      headers,
      body: JSON.stringify({ error: 'No authorization header' })
    };
  }

  const token = authHeader.split(' ')[1];
  let decoded;
  try {
    decoded = jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    return {
      statusCode: 401,
      headers,
      body: JSON.stringify({ error: 'Invalid token' })
    };
  }

  const userId = decoded.userId;

  if (path === '/contacts' && method === 'GET') {
    const contacts = await Contact.find({ userId }).sort({ updatedAt: -1 });
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(contacts)
    };
  }

  if (path.match(/^\/contacts\/[a-f\d]{24}$/) && method === 'GET') {
    const contactId = path.split('/')[2];
    const contact = await Contact.findOne({ _id: contactId, userId });
    
    if (!contact) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ error: 'Contact not found' })
      };
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(contact)
    };
  }

  return {
    statusCode: 404,
    headers,
    body: JSON.stringify({ error: 'Contact route not found' })
  };
}

async function handleImport(path, method, event, headers) {
  if (path.startsWith('/import/stats/') && method === 'GET') {
    const userId = path.split('/')[3];
    
    const stats = await Contact.aggregate([
      { $match: { userId } },
      {
        $group: {
          _id: null,
          total: { $sum: 1 },
          enriched: { $sum: { $cond: [{ $eq: ['$enriched', true] }, 1, 0] } },
          hubspotImports: { $sum: { $cond: [{ $eq: ['$source', 'hubspot'] }, 1, 0] } },
          withLinkedIn: { $sum: { $cond: [{ $exists: ['$socialProfiles.linkedin'] }, 1, 0] } }
        }
      }
    ]);

    const result = stats[0] || {
      total: 0,
      enriched: 0,
      hubspotImports: 0,
      withLinkedIn: 0
    };

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ success: true, stats: result })
    };
  }

  // For now, return a simple response for file uploads
  // Full file upload handling would require more complex setup in Netlify Functions
  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({ 
      success: false, 
      message: 'File upload functionality requires backend server. Please use Railway deployment for full functionality.' 
    })
  };
}