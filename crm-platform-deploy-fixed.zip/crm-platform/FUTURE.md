# FUTURE.md

## 🧠 Objective
Migrate the current Gmail/LinkedIn connection tracker into a full agent-based outbound engine with enriched lead intelligence, messaging automation, CRM sync, and performance scoring — built with scalable infra, containerized agents, and secure, monitored services.

---

## 🔄 SYSTEM UPGRADE TASKS

### 🔧 Infra + Storage

- [ ] **Migrate from local storage to PostgreSQL**
  - Normalize schema: `leads`, `contacts`, `outreach_logs`, `campaign_scores`
  - Enable row-level history/versioning for leads
  - Add `intent_score`, `bio`, and `engagement_state` fields

- [ ] **Containerize local LLM (Ollama or LM Studio)**
  - Dockerize inference server
  - Mount model volumes
  - Expose endpoint on internal network for bio/message generation

- [ ] **Airflow + Celery pipelines**
  - Airflow: Schedule scrape → enrich → message → score DAGs
  - Celery: Real-time agent triggers (e.g., on reply)

---

## 🧱 Backend + API

- [ ] **Refactor API layer**
  - Switch to FastAPI
  - Modular agent endpoints: `/leads`, `/enrich`, `/score`
  - JWT auth for internal services

- [ ] **Salesforce sync module**
  - Use `simple-salesforce`
  - Trigger on positive reply → upsert contact

---

## 🚀 DevOps / CI/CD

- [ ] **Set up CI/CD**
  - GitHub Actions or Railway Pipelines
  - Lint, format, test, deploy on push to `main`

- [ ] **Secure secrets management**
  - Switch from `.env` to Vault or Doppler
  - Encrypted secrets for LLM, SMTP, Salesforce

- [ ] **Monitoring + logging**
  - Integrate Prometheus + Grafana or use Supabase logs
  - Alert on pipeline failures or reply bounce rate spikes

---

## 📊 Reporting & Dashboard

- [ ] **Streamlit/Next.js dashboard**
  - Display active leads, engagement funnels, booking rates
  - Filter by campaign, persona, or source
  - Manual override of lead state / retry / reassign

---

## 🧠 Agent Roles for This Iteration

- `system-architect`: Define system topology, DB schema, service boundaries  
- `backend-dev`: Build API layer, Airflow/Celery tasks, enrichers  
- `coder`: Low-level Python implementation of agents, scraping, parsing  
- `cicd-engineer`: GitHub Actions, Docker, deployment pipelines  
- `security-manager`: Secrets, access control, encrypted storage  
- `performance-monitor`: Logging, alerting, score deltas, API latency tracking

---

## 🗂 Related Files
- `lead_enrichment_flow.yaml` – Agent flow definition
- `db/schema.sql` – Postgres schema
- `docker/ollama.dockerfile` – LLM container
- `.github/workflows/ci.yml` – CI/CD config
