const mongoose = require('mongoose');
const User = require('./models/User');
require('dotenv').config();

async function testLogin() {
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    
    console.log('Testing login functionality...');
    
    const user = await User.findOne({ email: 'test@crm.com' });
    if (!user) {
      console.log('❌ User not found');
      return;
    }
    
    console.log('✅ User found:', user.email);
    
    const passwordMatch = await user.comparePassword('password123');
    console.log('✅ Password match:', passwordMatch);
    
    if (passwordMatch) {
      console.log('🎉 Login test successful!');
      console.log('The issue is likely with the server connection, not authentication.');
    } else {
      console.log('❌ Password verification failed');
    }
    
  } catch (error) {
    console.error('Test error:', error);
  } finally {
    mongoose.connection.close();
  }
}

testLogin();