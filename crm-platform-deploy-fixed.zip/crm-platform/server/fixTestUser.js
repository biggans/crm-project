const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const User = require('./models/User');

async function fixTestUser() {
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    
    console.log('Connected to MongoDB');

    // Delete existing test user
    await User.deleteOne({ email: 'test@crm.com' });
    console.log('Deleted existing test user');

    // Create new test user with proper password hashing
    const testUser = new User({
      firstName: 'Test',
      lastName: 'User',
      email: 'test@crm.com',
      password: 'password123'  // This will be hashed by the User model's pre-save hook
    });

    await testUser.save();
    console.log('✅ New test user created!');
    
    // Verify the password works
    const savedUser = await User.findOne({ email: 'test@crm.com' });
    const passwordMatch = await savedUser.comparePassword('password123');
    
    console.log('📧 Email: test@crm.com');
    console.log('🔑 Password: password123');
    console.log('✅ Password verification:', passwordMatch ? 'SUCCESS' : 'FAILED');
    
  } catch (error) {
    console.error('Error:', error);
  } finally {
    mongoose.connection.close();
  }
}

fixTestUser();