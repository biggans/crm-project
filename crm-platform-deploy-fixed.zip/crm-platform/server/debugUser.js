const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const User = require('./models/User');

async function debugUser() {
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    
    console.log('Connected to MongoDB');

    // Find the test user
    const user = await User.findOne({ email: 'test@crm.com' });
    
    if (!user) {
      console.log('❌ Test user not found!');
      return;
    }

    console.log('✅ Test user found:');
    console.log('Email:', user.email);
    console.log('First Name:', user.firstName);
    console.log('Last Name:', user.lastName);
    console.log('Password Hash:', user.password.substring(0, 20) + '...');
    
    // Test password comparison
    const passwordMatch = await user.comparePassword('password123');
    console.log('Password comparison result:', passwordMatch);
    
    // Test bcrypt directly
    const directMatch = await bcrypt.compare('password123', user.password);
    console.log('Direct bcrypt comparison:', directMatch);
    
  } catch (error) {
    console.error('Error:', error);
  } finally {
    mongoose.connection.close();
  }
}

debugUser();