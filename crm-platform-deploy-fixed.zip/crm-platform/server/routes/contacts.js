const express = require('express');
const router = express.Router();
const Contact = require('../models/Contact');
const Interaction = require('../models/Interaction');

router.get('/', async (req, res) => {
  try {
    const { 
      page = 1, 
      limit = 50, 
      search, 
      company, 
      tags, 
      priority,
      status = 'active',
      sortBy = 'lastContact',
      sortOrder = 'desc'
    } = req.query;

    const query = { status };
    
    if (search) {
      query.$or = [
        { firstName: { $regex: search, $options: 'i' } },
        { lastName: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { company: { $regex: search, $options: 'i' } }
      ];
    }

    if (company) {
      query.company = { $regex: company, $options: 'i' };
    }

    if (tags) {
      query.tags = { $in: tags.split(',') };
    }

    if (priority) {
      query.priority = priority;
    }

    const sortOptions = {};
    sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;

    const contacts = await Contact.find(query)
      .sort(sortOptions)
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();

    const total = await Contact.countDocuments(query);

    res.json({
      contacts,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const contact = await Contact.findById(req.params.id);
    if (!contact) {
      return res.status(404).json({ error: 'Contact not found' });
    }

    const interactions = await Interaction.find({ contact: contact._id })
      .sort({ date: -1 })
      .limit(50);

    res.json({ contact, interactions });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const contactData = {
      ...req.body,
      source: 'manual'
    };

    const existingContact = await Contact.findOne({ email: contactData.email });
    if (existingContact) {
      return res.status(400).json({ error: 'Contact with this email already exists' });
    }

    const contact = new Contact(contactData);
    await contact.save();

    res.status(201).json(contact);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const contact = await Contact.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!contact) {
      return res.status(404).json({ error: 'Contact not found' });
    }

    res.json(contact);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const contact = await Contact.findByIdAndUpdate(
      req.params.id,
      { status: 'archived' },
      { new: true }
    );

    if (!contact) {
      return res.status(404).json({ error: 'Contact not found' });
    }

    res.json({ message: 'Contact archived successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/:id/interactions', async (req, res) => {
  try {
    const interactionData = {
      ...req.body,
      contact: req.params.id
    };

    const interaction = new Interaction(interactionData);
    await interaction.save();

    await Contact.findByIdAndUpdate(req.params.id, {
      lastContact: new Date()
    });

    res.status(201).json(interaction);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/:id/interactions', async (req, res) => {
  try {
    const { page = 1, limit = 20, type } = req.query;
    
    const query = { contact: req.params.id };
    if (type) {
      query.type = type;
    }

    const interactions = await Interaction.find(query)
      .sort({ date: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();

    const total = await Interaction.countDocuments(query);

    res.json({
      interactions,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/stats/summary', async (req, res) => {
  try {
    const totalContacts = await Contact.countDocuments({ status: 'active' });
    const totalCompanies = await Contact.distinct('company').then(companies => 
      companies.filter(company => company && company.trim()).length
    );
    
    const recentInteractions = await Interaction.countDocuments({
      date: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
    });

    const topCompanies = await Contact.aggregate([
      { $match: { status: 'active', company: { $exists: true, $ne: '' } } },
      { $group: { _id: '$company', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 5 }
    ]);

    res.json({
      totalContacts,
      totalCompanies,
      recentInteractions,
      topCompanies
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;