const { google } = require('googleapis');
const Contact = require('../models/Contact');
const Interaction = require('../models/Interaction');

class GmailService {
  constructor() {
    this.oauth2Client = new google.auth.OAuth2(
      process.env.GMAIL_CLIENT_ID,
      process.env.GMAIL_CLIENT_SECRET,
      process.env.GMAIL_REDIRECT_URI
    );
  }

  getAuthUrl() {
    const scopes = [
      'https://www.googleapis.com/auth/gmail.readonly',
      'https://www.googleapis.com/auth/userinfo.email'
    ];

    return this.oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes
    });
  }

  async getAccessToken(code) {
    const { tokens } = await this.oauth2Client.getToken(code);
    return tokens;
  }

  async setCredentials(tokens) {
    this.oauth2Client.setCredentials(tokens);
    this.gmail = google.gmail({ version: 'v1', auth: this.oauth2Client });
  }

  async syncEmails(userId, lastSyncDate = null) {
    try {
      const query = lastSyncDate ? `after:${Math.floor(lastSyncDate.getTime() / 1000)}` : '';
      
      const response = await this.gmail.users.messages.list({
        userId: 'me',
        q: query,
        maxResults: 100
      });

      const messages = response.data.messages || [];
      const contacts = new Map();
      const interactions = [];

      for (const message of messages) {
        const messageData = await this.gmail.users.messages.get({
          userId: 'me',
          id: message.id,
          format: 'full'
        });

        const email = this.parseEmailMessage(messageData.data);
        
        if (email.from && email.from !== 'me') {
          const contactData = this.extractContactFromEmail(email);
          const contactKey = contactData.email;
          
          if (!contacts.has(contactKey)) {
            contacts.set(contactKey, contactData);
          }

          interactions.push({
            type: 'email',
            direction: 'inbound',
            subject: email.subject,
            content: email.body,
            platform: 'gmail',
            externalId: message.id,
            metadata: {
              messageId: email.messageId,
              threadId: email.threadId
            },
            date: new Date(email.date),
            email: contactData.email
          });
        }

        if (email.to && email.to.length > 0) {
          for (const recipient of email.to) {
            if (recipient !== 'me') {
              const contactData = this.extractContactFromEmail({ from: recipient });
              const contactKey = contactData.email;
              
              if (!contacts.has(contactKey)) {
                contacts.set(contactKey, contactData);
              }

              interactions.push({
                type: 'email',
                direction: 'outbound',
                subject: email.subject,
                content: email.body,
                platform: 'gmail',
                externalId: message.id,
                metadata: {
                  messageId: email.messageId,
                  threadId: email.threadId
                },
                date: new Date(email.date),
                email: contactData.email
              });
            }
          }
        }
      }

      await this.saveContactsAndInteractions(Array.from(contacts.values()), interactions);
      
      return {
        contactsProcessed: contacts.size,
        interactionsProcessed: interactions.length
      };
    } catch (error) {
      console.error('Gmail sync error:', error);
      throw error;
    }
  }

  parseEmailMessage(message) {
    const headers = message.payload.headers;
    const getHeader = (name) => {
      const header = headers.find(h => h.name.toLowerCase() === name.toLowerCase());
      return header ? header.value : '';
    };

    let body = '';
    if (message.payload.body && message.payload.body.data) {
      body = Buffer.from(message.payload.body.data, 'base64').toString();
    } else if (message.payload.parts) {
      const textPart = message.payload.parts.find(part => 
        part.mimeType === 'text/plain' || part.mimeType === 'text/html'
      );
      if (textPart && textPart.body && textPart.body.data) {
        body = Buffer.from(textPart.body.data, 'base64').toString();
      }
    }

    return {
      messageId: getHeader('Message-ID'),
      threadId: message.threadId,
      from: getHeader('From'),
      to: getHeader('To').split(',').map(email => email.trim()),
      subject: getHeader('Subject'),
      date: getHeader('Date'),
      body: body.substring(0, 1000)
    };
  }

  extractContactFromEmail(email) {
    const emailMatch = email.from.match(/<(.+)>/);
    const emailAddress = emailMatch ? emailMatch[1] : email.from;
    
    const nameMatch = email.from.match(/^(.+?)\s*</);
    const fullName = nameMatch ? nameMatch[1].replace(/"/g, '').trim() : '';
    
    const nameParts = fullName.split(' ');
    const firstName = nameParts[0] || '';
    const lastName = nameParts.slice(1).join(' ') || '';

    return {
      firstName: firstName || 'Unknown',
      lastName: lastName || 'Contact',
      email: emailAddress.toLowerCase(),
      source: 'gmail',
      lastContact: new Date()
    };
  }

  async saveContactsAndInteractions(contactsData, interactionsData) {
    for (const contactData of contactsData) {
      try {
        let contact = await Contact.findOne({ email: contactData.email });
        
        if (!contact) {
          contact = new Contact(contactData);
          await contact.save();
        } else {
          contact.lastContact = new Date();
          await contact.save();
        }

        const contactInteractions = interactionsData.filter(i => i.email === contactData.email);
        for (const interactionData of contactInteractions) {
          const { email, ...cleanInteractionData } = interactionData;
          cleanInteractionData.contact = contact._id;
          
          const existingInteraction = await Interaction.findOne({
            externalId: cleanInteractionData.externalId,
            platform: 'gmail'
          });
          
          if (!existingInteraction) {
            const interaction = new Interaction(cleanInteractionData);
            await interaction.save();
          }
        }
      } catch (error) {
        console.error(`Error saving contact ${contactData.email}:`, error);
      }
    }
  }
}

module.exports = GmailService;