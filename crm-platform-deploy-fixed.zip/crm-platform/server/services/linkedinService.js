const axios = require('axios');
const Contact = require('../models/Contact');
const Interaction = require('../models/Interaction');

class LinkedInService {
  constructor() {
    this.clientId = process.env.LINKEDIN_CLIENT_ID;
    this.clientSecret = process.env.LINKEDIN_CLIENT_SECRET;
    this.redirectUri = process.env.LINKEDIN_REDIRECT_URI;
    this.baseUrl = 'https://api.linkedin.com/v2';
  }

  getAuthUrl() {
    const scope = 'r_liteprofile r_emailaddress w_member_social';
    const state = Math.random().toString(36).substring(7);
    
    return `https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id=${this.clientId}&redirect_uri=${encodeURIComponent(this.redirectUri)}&state=${state}&scope=${encodeURIComponent(scope)}`;
  }

  async getAccessToken(code) {
    try {
      const response = await axios.post('https://www.linkedin.com/oauth/v2/accessToken', {
        grant_type: 'authorization_code',
        code,
        redirect_uri: this.redirectUri,
        client_id: this.clientId,
        client_secret: this.clientSecret
      }, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      });

      return response.data;
    } catch (error) {
      throw new Error(`LinkedIn OAuth error: ${error.message}`);
    }
  }

  async getUserProfile(accessToken) {
    try {
      const [profileResponse, emailResponse] = await Promise.all([
        axios.get(`${this.baseUrl}/people/~:(id,firstName,lastName,headline,industry,positions)`, {
          headers: { Authorization: `Bearer ${accessToken}` }
        }),
        axios.get(`${this.baseUrl}/emailAddress?q=members&projection=(elements*(handle~))`, {
          headers: { Authorization: `Bearer ${accessToken}` }
        })
      ]);

      const profile = profileResponse.data;
      const email = emailResponse.data.elements[0]['handle~'].emailAddress;

      return {
        id: profile.id,
        firstName: profile.firstName.localized.en_US,
        lastName: profile.lastName.localized.en_US,
        email,
        headline: profile.headline,
        industry: profile.industry,
        positions: profile.positions
      };
    } catch (error) {
      throw new Error(`LinkedIn profile fetch error: ${error.message}`);
    }
  }

  async getConnections(accessToken) {
    try {
      const response = await axios.get(`${this.baseUrl}/people/~:connections:(id,firstName,lastName,headline,industry,positions,site-standard-profile-request)`, {
        headers: { Authorization: `Bearer ${accessToken}` }
      });

      return response.data.values || [];
    } catch (error) {
      console.warn('LinkedIn connections API may be restricted. Using alternative approach.');
      return [];
    }
  }

  async searchPeople(accessToken, keywords, start = 0, count = 25) {
    try {
      const response = await axios.get(`${this.baseUrl}/people-search`, {
        params: {
          keywords,
          start,
          count,
          facet: 'network,N'
        },
        headers: { Authorization: `Bearer ${accessToken}` }
      });

      return response.data.people || [];
    } catch (error) {
      throw new Error(`LinkedIn search error: ${error.message}`);
    }
  }

  async syncConnections(userId, accessToken) {
    try {
      const connections = await this.getConnections(accessToken);
      const contacts = [];
      const interactions = [];

      for (const connection of connections) {
        const contactData = this.extractContactFromLinkedInProfile(connection);
        contacts.push(contactData);

        interactions.push({
          type: 'linkedin_connection',
          direction: 'inbound',
          subject: 'LinkedIn Connection',
          content: `Connected on LinkedIn - ${connection.headline || 'No headline'}`,
          platform: 'linkedin',
          externalId: connection.id,
          date: new Date(),
          email: contactData.email || `${connection.id}@linkedin.placeholder`
        });
      }

      await this.saveContactsAndInteractions(contacts, interactions);

      return {
        contactsProcessed: contacts.length,
        interactionsProcessed: interactions.length
      };
    } catch (error) {
      console.error('LinkedIn sync error:', error);
      throw error;
    }
  }

  extractContactFromLinkedInProfile(profile) {
    const firstName = profile.firstName?.localized?.en_US || 
                     profile.firstName?.preferredLocale?.language || 
                     profile.firstName || 'Unknown';
    
    const lastName = profile.lastName?.localized?.en_US || 
                    profile.lastName?.preferredLocale?.language || 
                    profile.lastName || 'Contact';

    const position = profile.positions?.values?.[0];
    const company = position?.company?.name || '';
    const jobTitle = position?.title || profile.headline || '';

    return {
      firstName,
      lastName,
      email: profile.email || `${profile.id}@linkedin.placeholder`,
      company,
      position: jobTitle,
      socialProfiles: {
        linkedin: {
          url: profile.siteStandardProfileRequest?.url || `https://linkedin.com/in/${profile.id}`,
          profileId: profile.id,
          lastSync: new Date()
        }
      },
      source: 'linkedin',
      lastContact: new Date()
    };
  }

  async saveContactsAndInteractions(contactsData, interactionsData) {
    for (const contactData of contactsData) {
      try {
        let contact = await Contact.findOne({ 
          $or: [
            { email: contactData.email },
            { 'socialProfiles.linkedin.profileId': contactData.socialProfiles?.linkedin?.profileId }
          ]
        });
        
        if (!contact) {
          contact = new Contact(contactData);
          await contact.save();
        } else {
          contact.lastContact = new Date();
          if (contactData.socialProfiles?.linkedin) {
            contact.socialProfiles.linkedin = contactData.socialProfiles.linkedin;
          }
          if (contactData.company && !contact.company) {
            contact.company = contactData.company;
          }
          if (contactData.position && !contact.position) {
            contact.position = contactData.position;
          }
          await contact.save();
        }

        const contactInteractions = interactionsData.filter(i => 
          i.email === contactData.email || 
          i.externalId === contactData.socialProfiles?.linkedin?.profileId
        );
        
        for (const interactionData of contactInteractions) {
          const { email, ...cleanInteractionData } = interactionData;
          cleanInteractionData.contact = contact._id;
          
          const existingInteraction = await Interaction.findOne({
            externalId: cleanInteractionData.externalId,
            platform: 'linkedin'
          });
          
          if (!existingInteraction) {
            const interaction = new Interaction(cleanInteractionData);
            await interaction.save();
          }
        }
      } catch (error) {
        console.error(`Error saving LinkedIn contact:`, error);
      }
    }
  }
}

module.exports = LinkedInService;