const csvParser = require('csv-parser');
const fs = require('fs');
const Contact = require('../models/Contact');

class GmailImportService {
  async importFromCSV(filePath, userId) {
    return new Promise((resolve, reject) => {
      const contacts = [];
      const results = {
        processed: 0,
        imported: 0,
        enriched: 0,
        errors: []
      };

      fs.createReadStream(filePath)
        .pipe(csvParser())
        .on('data', (row) => {
          try {
            // Google Contacts CSV format mapping
            const contact = this.mapGoogleContactsFields(row, userId);
            if (contact) {
              contacts.push(contact);
              results.processed++;
            }
          } catch (error) {
            results.errors.push({
              row: results.processed + 1,
              error: error.message,
              data: row
            });
          }
        })
        .on('end', async () => {
          try {
            // Bulk insert/update contacts
            for (const contactData of contacts) {
              try {
                await this.saveContact(contactData);
                results.imported++;
              } catch (error) {
                results.errors.push({
                  contact: contactData.email || contactData.firstName + ' ' + contactData.lastName,
                  error: error.message
                });
              }
            }

            resolve(results);
          } catch (error) {
            reject(error);
          }
        })
        .on('error', (error) => {
          reject(error);
        });
    });
  }

  async importFromMbox(filePath, userId) {
    return new Promise((resolve, reject) => {
      const results = {
        processed: 0,
        imported: 0,
        enriched: 0,
        errors: []
      };

      try {
        // Read MBOX file and extract email addresses
        const mboxContent = fs.readFileSync(filePath, 'utf-8');
        const emailAddresses = this.extractEmailsFromMbox(mboxContent);
        
        this.processEmailAddresses(emailAddresses, userId)
          .then((processResults) => {
            results.processed = emailAddresses.length;
            results.imported = processResults.imported;
            results.errors = processResults.errors;
            resolve(results);
          })
          .catch(reject);
      } catch (error) {
        reject(error);
      }
    });
  }

  extractEmailsFromMbox(mboxContent) {
    const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
    const emails = new Set();
    
    // Extract From: and To: email addresses
    const fromMatches = mboxContent.match(/^From:.*$/gm) || [];
    const toMatches = mboxContent.match(/^To:.*$/gm) || [];
    const ccMatches = mboxContent.match(/^Cc:.*$/gm) || [];
    
    [...fromMatches, ...toMatches, ...ccMatches].forEach(line => {
      const matches = line.match(emailRegex);
      if (matches) {
        matches.forEach(email => emails.add(email.toLowerCase()));
      }
    });

    // Also extract from email body content
    const bodyMatches = mboxContent.match(emailRegex) || [];
    bodyMatches.forEach(email => emails.add(email.toLowerCase()));

    // Filter out common system emails
    const systemEmails = [
      'noreply@', 'no-reply@', 'donotreply@', 'mailer-daemon@',
      'postmaster@', 'bounce@', 'newsletter@', 'marketing@'
    ];
    
    return Array.from(emails).filter(email => {
      return !systemEmails.some(systemEmail => email.includes(systemEmail));
    });
  }

  async processEmailAddresses(emailAddresses, userId) {
    const results = { imported: 0, errors: [] };
    
    for (const email of emailAddresses) {
      try {
        const contactData = {
          userId,
          email,
          firstName: '',
          lastName: '',
          source: 'gmail',
          tags: ['gmail-contact'],
          notes: 'Extracted from Gmail emails',
          createdAt: new Date(),
          updatedAt: new Date()
        };

        // Try to extract name from email
        const namePart = email.split('@')[0];
        if (namePart.includes('.')) {
          const parts = namePart.split('.');
          contactData.firstName = this.capitalizeFirst(parts[0]);
          contactData.lastName = this.capitalizeFirst(parts[1]);
        } else {
          contactData.firstName = this.capitalizeFirst(namePart);
        }

        await this.saveContact(contactData);
        results.imported++;
      } catch (error) {
        results.errors.push({
          email,
          error: error.message
        });
      }
    }

    return results;
  }

  mapGoogleContactsFields(row, userId) {
    // Google Contacts CSV field mappings
    const nameFields = ['Name', 'Given Name', 'Family Name'];
    const emailFields = ['E-mail 1 - Value', 'E-mail Address', 'Email', 'Primary Email'];
    const phoneFields = ['Phone 1 - Value', 'Phone Number', 'Primary Phone'];
    const companyFields = ['Organization 1 - Name', 'Company', 'Organization'];
    const titleFields = ['Organization 1 - Title', 'Job Title', 'Title'];

    const name = this.findFieldValue(row, nameFields);
    const email = this.findFieldValue(row, emailFields);
    const phone = this.findFieldValue(row, phoneFields);
    const company = this.findFieldValue(row, companyFields);
    const jobTitle = this.findFieldValue(row, titleFields);

    // Must have at least name or email
    if (!name && !email) {
      return null;
    }

    // Parse name
    let firstName = row['Given Name'] || '';
    let lastName = row['Family Name'] || '';
    
    if (!firstName && !lastName && name) {
      const nameParts = name.split(' ');
      firstName = nameParts[0] || '';
      lastName = nameParts.slice(1).join(' ') || '';
    }

    const contact = {
      userId,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      email: email || '',
      phone: phone || '',
      company: company || '',
      jobTitle: jobTitle || '',
      source: 'gmail',
      tags: ['gmail-contact'],
      notes: 'Imported from Google Contacts',
      createdAt: new Date(),
      updatedAt: new Date()
    };

    return contact;
  }

  findFieldValue(row, fieldNames) {
    for (const fieldName of fieldNames) {
      if (row[fieldName] && row[fieldName].trim()) {
        return row[fieldName].trim();
      }
    }
    return '';
  }

  capitalizeFirst(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  }

  async saveContact(contactData) {
    try {
      // Check if contact already exists by email
      if (contactData.email) {
        const existingContact = await Contact.findOne({
          userId: contactData.userId,
          email: contactData.email
        });

        if (existingContact) {
          // Update existing contact with Gmail data
          const updatedData = {
            tags: [...new Set([...(existingContact.tags || []), ...contactData.tags])],
            updatedAt: new Date()
          };

          // Only update fields that are empty
          if (!existingContact.phone && contactData.phone) {
            updatedData.phone = contactData.phone;
          }
          if (!existingContact.company && contactData.company) {
            updatedData.company = contactData.company;
          }
          if (!existingContact.jobTitle && contactData.jobTitle) {
            updatedData.jobTitle = contactData.jobTitle;
          }

          await Contact.findByIdAndUpdate(existingContact._id, updatedData);
          return existingContact;
        }
      }

      // Create new contact
      const newContact = new Contact(contactData);
      await newContact.save();
      return newContact;
    } catch (error) {
      console.error('Error saving Gmail contact:', error);
      throw error;
    }
  }
}

module.exports = GmailImportService;