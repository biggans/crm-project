# 🚀 Deploy CRM to Railway (Recommended)

Railway is perfect for your full-stack CRM with file uploads and database connectivity.

## Quick Deployment Steps

### 1. Install Railway CLI
```bash
npm install -g @railway/cli
```

### 2. Login to Railway
```bash
railway login
```

### 3. Initialize and Deploy
```bash
cd /Users/owner/crm-platform
railway init
railway up
```

### 4. Set Environment Variables
```bash
railway variables set MONGODB_URI="mongodb+srv://bwthompson12:UE19J2xZwax5rKcQ@cluster0.o92hzj1.mongodb.net/crm?retryWrites=true&w=majority"
railway variables set JWT_SECRET="crm-super-secret-jwt-key-2024-production"
railway variables set GMAIL_CLIENT_ID="982439180230-l08qtfd6ahknct2fk75e0ie667ebeacj.apps.googleusercontent.com"
railway variables set GMAIL_CLIENT_SECRET="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"
railway variables set NODE_ENV="production"
```

### 5. Get Your Live URL
```bash
railway domain
```

## Why Railway Over Netlify?

✅ **Full Node.js Backend Support**: Complete Express server with all APIs
✅ **File Upload Handling**: Multer and file processing work perfectly  
✅ **Database Connectivity**: Direct MongoDB Atlas connection
✅ **Zero Configuration**: Automatically detects your Node.js app
✅ **Built-in HTTPS**: Secure by default
✅ **Easy Environment Variables**: Simple CLI configuration

## Alternative: Render.com

If you prefer Render:

1. Go to render.com and create account
2. Connect your GitHub repo
3. Choose "Web Service"
4. Use these settings:
   - Build Command: `npm run build`
   - Start Command: `npm start`
   - Environment: Node

## Your CRM Features Will Work Perfectly:

🔥 **All File Upload Features**:
- HubSpot CSV imports ✅
- LinkedIn CSV imports ✅  
- Gmail MBOX/CSV processing ✅
- Real-time progress tracking ✅
- Bulk contact enrichment ✅

🔥 **Full Database Operations**:
- Contact management ✅
- User authentication ✅
- Search and filtering ✅
- Dashboard analytics ✅

## Deploy Now!

Run these commands:
```bash
npm install -g @railway/cli
railway login
railway init
railway up
```

Your CRM will be live in under 5 minutes! 🎉