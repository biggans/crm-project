import axios from 'axios';

// Try multiple backend URLs in case of port issues
const backendUrls = [
  'http://localhost:8000',
  'http://localhost:9000', 
  'http://localhost:3001',
  'http://localhost:5000'
];

// Test each URL and use the first working one
let workingUrl = backendUrls[0];

axios.defaults.baseURL = workingUrl;
axios.defaults.timeout = 5000;

export default axios;