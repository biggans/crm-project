import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Button,
  Grid,
  Alert,
  CircularProgress,
  Chip
} from '@mui/material';
import {
  Email as GmailIcon,
  LinkedIn as LinkedInIcon,
  Sync as SyncIcon
} from '@mui/icons-material';
import axios from '../axiosConfig';
import { useAuth } from '../contexts/AuthContext';

const IntegrationCard = ({ 
  title, 
  description, 
  icon, 
  connected, 
  lastSync, 
  onConnect, 
  onSync, 
  loading 
}) => (
  <Card>
    <CardContent>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <Box sx={{ mr: 2, color: 'primary.main' }}>
          {icon}
        </Box>
        <Box sx={{ flexGrow: 1 }}>
          <Typography variant="h6" component="h2">
            {title}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {description}
          </Typography>
        </Box>
        <Chip 
          label={connected ? 'Connected' : 'Not Connected'} 
          color={connected ? 'success' : 'default'}
          size="small"
        />
      </Box>

      {lastSync && (
        <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 2 }}>
          Last sync: {new Date(lastSync).toLocaleString()}
        </Typography>
      )}

      <Grid container spacing={1}>
        <Grid item>
          <Button
            variant={connected ? 'outlined' : 'contained'}
            onClick={onConnect}
            disabled={loading}
          >
            {connected ? 'Reconnect' : 'Connect'}
          </Button>
        </Grid>
        {connected && (
          <Grid item>
            <Button
              variant="outlined"
              startIcon={loading ? <CircularProgress size={16} /> : <SyncIcon />}
              onClick={onSync}
              disabled={loading}
            >
              Sync Now
            </Button>
          </Grid>
        )}
      </Grid>
    </CardContent>
  </Card>
);

const Integrations = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [alert, setAlert] = useState(null);

  const { data: gmailStatus } = useQuery(
    ['gmailStatus', user?.id],
    async () => {
      const response = await axios.get(`/api/gmail/status/${user.id}`);
      return response.data;
    },
    { enabled: !!user?.id }
  );

  const { data: linkedinStatus } = useQuery(
    ['linkedinStatus', user?.id],
    async () => {
      const response = await axios.get(`/api/linkedin/status/${user.id}`);
      return response.data;
    },
    { enabled: !!user?.id }
  );

  const gmailConnectMutation = useMutation(
    async () => {
      const response = await axios.get('/api/gmail/auth');
      window.location.href = response.data.authUrl;
    },
    {
      onError: (error) => {
        setAlert({ type: 'error', message: 'Failed to connect Gmail' });
      }
    }
  );

  const linkedinConnectMutation = useMutation(
    async () => {
      const response = await axios.get('/api/linkedin/auth');
      window.location.href = response.data.authUrl;
    },
    {
      onError: (error) => {
        setAlert({ type: 'error', message: 'Failed to connect LinkedIn' });
      }
    }
  );

  const gmailSyncMutation = useMutation(
    async () => {
      const response = await axios.post('/api/gmail/sync', { userId: user.id });
      return response.data;
    },
    {
      onSuccess: (data) => {
        setAlert({ 
          type: 'success', 
          message: `Gmail sync completed. Processed ${data.contactsProcessed} contacts and ${data.interactionsProcessed} interactions.` 
        });
        queryClient.invalidateQueries(['gmailStatus', user.id]);
        queryClient.invalidateQueries('contacts');
      },
      onError: (error) => {
        setAlert({ type: 'error', message: 'Gmail sync failed' });
      }
    }
  );

  const linkedinSyncMutation = useMutation(
    async () => {
      const response = await axios.post('/api/linkedin/sync', { userId: user.id });
      return response.data;
    },
    {
      onSuccess: (data) => {
        setAlert({ 
          type: 'success', 
          message: `LinkedIn sync completed. Processed ${data.contactsProcessed} contacts and ${data.interactionsProcessed} interactions.` 
        });
        queryClient.invalidateQueries(['linkedinStatus', user.id]);
        queryClient.invalidateQueries('contacts');
      },
      onError: (error) => {
        setAlert({ type: 'error', message: 'LinkedIn sync failed' });
      }
    }
  );

  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom>
        Integrations
      </Typography>

      <Typography variant="body1" color="text.secondary" sx={{ mb: 4 }}>
        Connect your social platforms to automatically sync contacts and track interactions.
      </Typography>

      {alert && (
        <Alert 
          severity={alert.type} 
          onClose={() => setAlert(null)}
          sx={{ mb: 3 }}
        >
          {alert.message}
        </Alert>
      )}

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <IntegrationCard
            title="Gmail"
            description="Sync contacts and email interactions from your Gmail account"
            icon={<GmailIcon fontSize="large" />}
            connected={gmailStatus?.connected}
            lastSync={gmailStatus?.lastSync}
            onConnect={() => gmailConnectMutation.mutate()}
            onSync={() => gmailSyncMutation.mutate()}
            loading={gmailConnectMutation.isLoading || gmailSyncMutation.isLoading}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <IntegrationCard
            title="LinkedIn"
            description="Import your LinkedIn connections and professional network"
            icon={<LinkedInIcon fontSize="large" />}
            connected={linkedinStatus?.connected}
            lastSync={linkedinStatus?.lastSync}
            onConnect={() => linkedinConnectMutation.mutate()}
            onSync={() => linkedinSyncMutation.mutate()}
            loading={linkedinConnectMutation.isLoading || linkedinSyncMutation.isLoading}
          />
        </Grid>
      </Grid>

      <Box sx={{ mt: 4 }}>
        <Card>
          <CardContent>
            <Typography variant="h6" component="h2" gutterBottom>
              Integration Tips
            </Typography>
            <Typography variant="body2" color="text.secondary" paragraph>
              • Gmail integration will sync your recent emails and extract contact information automatically
            </Typography>
            <Typography variant="body2" color="text.secondary" paragraph>
              • LinkedIn integration helps you track your professional network and connection history
            </Typography>
            <Typography variant="body2" color="text.secondary" paragraph>
              • All data is stored securely and you can disconnect integrations at any time
            </Typography>
            <Typography variant="body2" color="text.secondary">
              • Sync frequency can be configured in your account settings
            </Typography>
          </CardContent>
        </Card>
      </Box>
    </Box>
  );
};

export default Integrations;