import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Button,
  Grid,
  Avatar,
  Chip,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  Edit as EditIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  Business as BusinessIcon,
  LinkedIn as LinkedInIcon,
  Add as AddIcon
} from '@mui/icons-material';
import axios from '../axiosConfig';

const ContactDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [interactionDialogOpen, setInteractionDialogOpen] = useState(false);
  const [editData, setEditData] = useState({});
  const [interactionData, setInteractionData] = useState({
    type: 'note',
    direction: 'outbound',
    subject: '',
    content: '',
    platform: 'manual'
  });

  const { data, isLoading, error } = useQuery(
    ['contact', id],
    async () => {
      const response = await axios.get(`/api/contacts/${id}`);
      return response.data;
    },
    { enabled: !!id }
  );

  const updateContactMutation = useMutation(
    async (updateData) => {
      const response = await axios.put(`/api/contacts/${id}`, updateData);
      return response.data;
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['contact', id]);
        setEditDialogOpen(false);
      }
    }
  );

  const addInteractionMutation = useMutation(
    async (newInteraction) => {
      const response = await axios.post(`/api/contacts/${id}/interactions`, newInteraction);
      return response.data;
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries(['contact', id]);
        setInteractionDialogOpen(false);
        setInteractionData({
          type: 'note',
          direction: 'outbound',
          subject: '',
          content: '',
          platform: 'manual'
        });
      }
    }
  );

  const handleEditContact = () => {
    setEditData(data.contact);
    setEditDialogOpen(true);
  };

  const handleSaveContact = () => {
    updateContactMutation.mutate(editData);
  };

  const handleAddInteraction = () => {
    addInteractionMutation.mutate({
      ...interactionData,
      date: new Date()
    });
  };

  const getInitials = (firstName, lastName) => {
    return `${firstName?.[0] || ''}${lastName?.[0] || ''}`.toUpperCase();
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleString();
  };

  const getInteractionIcon = (type) => {
    switch (type) {
      case 'email': return <EmailIcon />;
      case 'call': return <PhoneIcon />;
      case 'linkedin_message':
      case 'linkedin_connection': return <LinkedInIcon />;
      default: return <EmailIcon />;
    }
  };

  if (isLoading) return <Typography>Loading contact...</Typography>;
  if (error) return <Typography color="error">Error loading contact</Typography>;

  const contact = data.contact;
  const interactions = data.interactions;

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
        <IconButton onClick={() => navigate('/contacts')} sx={{ mr: 2 }}>
          <ArrowBackIcon />
        </IconButton>
        <Typography variant="h4" component="h1" sx={{ flexGrow: 1 }}>
          {contact.firstName} {contact.lastName}
        </Typography>
        <Button
          variant="outlined"
          startIcon={<EditIcon />}
          onClick={handleEditContact}
          sx={{ mr: 2 }}
        >
          Edit
        </Button>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setInteractionDialogOpen(true)}
        >
          Add Interaction
        </Button>
      </Box>

      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                <Avatar 
                  sx={{ width: 80, height: 80, mr: 2, bgcolor: 'primary.main' }}
                >
                  {getInitials(contact.firstName, contact.lastName)}
                </Avatar>
                <Box>
                  <Typography variant="h5" component="div">
                    {contact.firstName} {contact.lastName}
                  </Typography>
                  <Typography variant="body1" color="text.secondary">
                    {contact.position}
                  </Typography>
                  <Chip 
                    label={contact.priority} 
                    color={contact.priority === 'high' ? 'error' : 
                           contact.priority === 'medium' ? 'warning' : 'success'}
                    size="small"
                    sx={{ mt: 1 }}
                  />
                </Box>
              </Box>

              <Box sx={{ mb: 2 }}>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  Contact Information
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <EmailIcon sx={{ mr: 1, fontSize: 16 }} />
                  <Typography variant="body2">{contact.email}</Typography>
                </Box>
                {contact.phone && (
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <PhoneIcon sx={{ mr: 1, fontSize: 16 }} />
                    <Typography variant="body2">{contact.phone}</Typography>
                  </Box>
                )}
                {contact.company && (
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <BusinessIcon sx={{ mr: 1, fontSize: 16 }} />
                    <Typography variant="body2">{contact.company}</Typography>
                  </Box>
                )}
              </Box>

              {contact.socialProfiles?.linkedin?.url && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    Social Profiles
                  </Typography>
                  <Button
                    size="small"
                    startIcon={<LinkedInIcon />}
                    href={contact.socialProfiles.linkedin.url}
                    target="_blank"
                  >
                    LinkedIn Profile
                  </Button>
                </Box>
              )}

              {contact.tags && contact.tags.length > 0 && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    Tags
                  </Typography>
                  <Box>
                    {contact.tags.map((tag, index) => (
                      <Chip 
                        key={index}
                        label={tag} 
                        size="small" 
                        variant="outlined" 
                        sx={{ mr: 0.5, mb: 0.5 }}
                      />
                    ))}
                  </Box>
                </Box>
              )}

              {contact.notes && (
                <Box>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    Notes
                  </Typography>
                  <Typography variant="body2">{contact.notes}</Typography>
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={8}>
          <Card>
            <CardContent>
              <Typography variant="h6" component="h2" gutterBottom>
                Interaction History ({interactions.length})
              </Typography>
              <List>
                {interactions.map((interaction) => (
                  <ListItem key={interaction._id} divider>
                    <ListItemIcon>
                      {getInteractionIcon(interaction.type)}
                    </ListItemIcon>
                    <ListItemText
                      primary={
                        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                          <Typography variant="subtitle1">
                            {interaction.subject || `${interaction.type} ${interaction.direction}`}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {formatDate(interaction.date)}
                          </Typography>
                        </Box>
                      }
                      secondary={
                        <Box>
                          <Typography variant="body2" color="text.secondary">
                            {interaction.content}
                          </Typography>
                          <Box sx={{ mt: 1 }}>
                            <Chip 
                              label={interaction.platform} 
                              size="small" 
                              variant="outlined"
                              sx={{ mr: 1 }}
                            />
                            <Chip 
                              label={interaction.direction} 
                              size="small" 
                              color={interaction.direction === 'inbound' ? 'primary' : 'secondary'}
                            />
                          </Box>
                        </Box>
                      }
                    />
                  </ListItem>
                ))}
                {interactions.length === 0 && (
                  <ListItem>
                    <ListItemText
                      primary="No interactions yet"
                      secondary="Add your first interaction using the button above"
                    />
                  </ListItem>
                )}
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Edit Contact Dialog */}
      <Dialog open={editDialogOpen} onClose={() => setEditDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Edit Contact</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={6}>
              <TextField
                label="First Name"
                value={editData.firstName || ''}
                onChange={(e) => setEditData({...editData, firstName: e.target.value})}
                fullWidth
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Last Name"
                value={editData.lastName || ''}
                onChange={(e) => setEditData({...editData, lastName: e.target.value})}
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                label="Email"
                value={editData.email || ''}
                onChange={(e) => setEditData({...editData, email: e.target.value})}
                fullWidth
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Phone"
                value={editData.phone || ''}
                onChange={(e) => setEditData({...editData, phone: e.target.value})}
                fullWidth
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                label="Company"
                value={editData.company || ''}
                onChange={(e) => setEditData({...editData, company: e.target.value})}
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                label="Position"
                value={editData.position || ''}
                onChange={(e) => setEditData({...editData, position: e.target.value})}
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel>Priority</InputLabel>
                <Select
                  value={editData.priority || ''}
                  label="Priority"
                  onChange={(e) => setEditData({...editData, priority: e.target.value})}
                >
                  <MenuItem value="low">Low</MenuItem>
                  <MenuItem value="medium">Medium</MenuItem>
                  <MenuItem value="high">High</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                label="Notes"
                value={editData.notes || ''}
                onChange={(e) => setEditData({...editData, notes: e.target.value})}
                fullWidth
                multiline
                rows={3}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleSaveContact} variant="contained">Save</Button>
        </DialogActions>
      </Dialog>

      {/* Add Interaction Dialog */}
      <Dialog open={interactionDialogOpen} onClose={() => setInteractionDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Add Interaction</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={6}>
              <FormControl fullWidth>
                <InputLabel>Type</InputLabel>
                <Select
                  value={interactionData.type}
                  label="Type"
                  onChange={(e) => setInteractionData({...interactionData, type: e.target.value})}
                >
                  <MenuItem value="email">Email</MenuItem>
                  <MenuItem value="call">Phone Call</MenuItem>
                  <MenuItem value="meeting">Meeting</MenuItem>
                  <MenuItem value="note">Note</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={6}>
              <FormControl fullWidth>
                <InputLabel>Direction</InputLabel>
                <Select
                  value={interactionData.direction}
                  label="Direction"
                  onChange={(e) => setInteractionData({...interactionData, direction: e.target.value})}
                >
                  <MenuItem value="inbound">Inbound</MenuItem>
                  <MenuItem value="outbound">Outbound</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                label="Subject"
                value={interactionData.subject}
                onChange={(e) => setInteractionData({...interactionData, subject: e.target.value})}
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                label="Content"
                value={interactionData.content}
                onChange={(e) => setInteractionData({...interactionData, content: e.target.value})}
                fullWidth
                multiline
                rows={4}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setInteractionDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleAddInteraction} variant="contained">Add</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ContactDetail;