import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Button,
  Grid,
  LinearProgress,
  Alert,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Divider,
  CircularProgress,
  Chip,
  Tabs,
  Tab
} from '@mui/material';
import {
  CloudUpload as UploadIcon,
  AutoAwesome as EnrichIcon,
  Assessment as StatsIcon,
  CheckCircle as SuccessIcon,
  Error as ErrorIcon,
  LinkedIn as LinkedInIcon,
  Email as EmailIcon
} from '@mui/icons-material';
import axios from '../axiosConfig';
import { useAuth } from '../contexts/AuthContext';

const Import = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [tabValue, setTabValue] = useState(0);
  const [selectedFile, setSelectedFile] = useState(null);
  const [linkedinFile, setLinkedinFile] = useState(null);
  const [gmailFile, setGmailFile] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [importResults, setImportResults] = useState(null);

  const { data: stats, isLoading: statsLoading } = useQuery(
    ['importStats', user?.id],
    async () => {
      const response = await axios.get(`/api/import/stats/${user.id}`);
      return response.data.stats;
    },
    { enabled: !!user?.id }
  );

  const hubspotImportMutation = useMutation(
    async (formData) => {
      const response = await axios.post('/api/import/hubspot', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round(
            (progressEvent.loaded * 100) / progressEvent.total
          );
          setUploadProgress(percentCompleted);
        },
      });
      return response.data;
    },
    {
      onSuccess: (data) => {
        setImportResults(data.results);
        queryClient.invalidateQueries(['importStats', user.id]);
        queryClient.invalidateQueries('contacts');
        setSelectedFile(null);
        setUploadProgress(0);
      },
      onError: (error) => {
        console.error('Import error:', error);
        setUploadProgress(0);
      }
    }
  );

  const linkedinImportMutation = useMutation(
    async (formData) => {
      const response = await axios.post('/api/import/linkedin', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round(
            (progressEvent.loaded * 100) / progressEvent.total
          );
          setUploadProgress(percentCompleted);
        },
      });
      return response.data;
    },
    {
      onSuccess: (data) => {
        setImportResults(data.results);
        queryClient.invalidateQueries(['importStats', user.id]);
        queryClient.invalidateQueries('contacts');
        setLinkedinFile(null);
        setUploadProgress(0);
      },
      onError: (error) => {
        console.error('LinkedIn import error:', error);
        setUploadProgress(0);
      }
    }
  );

  const gmailImportMutation = useMutation(
    async (formData) => {
      const response = await axios.post('/api/import/gmail', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round(
            (progressEvent.loaded * 100) / progressEvent.total
          );
          setUploadProgress(percentCompleted);
        },
      });
      return response.data;
    },
    {
      onSuccess: (data) => {
        setImportResults(data.results);
        queryClient.invalidateQueries(['importStats', user.id]);
        queryClient.invalidateQueries('contacts');
        setGmailFile(null);
        setUploadProgress(0);
      },
      onError: (error) => {
        console.error('Gmail import error:', error);
        setUploadProgress(0);
      }
    }
  );

  const enrichMutation = useMutation(
    async () => {
      const response = await axios.post('/api/import/enrich', {
        userId: user.id
      });
      return response.data;
    },
    {
      onSuccess: (data) => {
        setImportResults(data.results);
        queryClient.invalidateQueries(['importStats', user.id]);
        queryClient.invalidateQueries('contacts');
      }
    }
  );

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file && file.type === 'text/csv') {
      setSelectedFile(file);
      setImportResults(null);
    } else {
      alert('Please select a CSV file');
    }
  };

  const handleLinkedinFileSelect = (event) => {
    const file = event.target.files[0];
    if (file && file.type === 'text/csv') {
      setLinkedinFile(file);
      setImportResults(null);
    } else {
      alert('Please select a CSV file');
    }
  };

  const handleGmailFileSelect = (event) => {
    const file = event.target.files[0];
    if (file && (file.type === 'text/csv' || file.name.endsWith('.mbox') || file.type === 'application/mbox')) {
      setGmailFile(file);
      setImportResults(null);
    } else {
      alert('Please select a CSV file or MBOX file');
    }
  };

  const handleImport = () => {
    if (!selectedFile || !user) return;

    const formData = new FormData();
    formData.append('csvFile', selectedFile);
    formData.append('userId', user.id);

    hubspotImportMutation.mutate(formData);
  };

  const handleLinkedinImport = () => {
    if (!linkedinFile || !user) return;

    const formData = new FormData();
    formData.append('csvFile', linkedinFile);
    formData.append('userId', user.id);

    linkedinImportMutation.mutate(formData);
  };

  const handleGmailImport = () => {
    if (!gmailFile || !user) return;

    const formData = new FormData();
    formData.append('emailFile', gmailFile);
    formData.append('userId', user.id);

    gmailImportMutation.mutate(formData);
  };

  const handleEnrich = () => {
    if (!user) return;
    enrichMutation.mutate();
  };

  const formatNumber = (num) => {
    return new Intl.NumberFormat().format(num || 0);
  };

  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom>
        📊 Import & Enrich Contacts
      </Typography>

      <Typography variant="body1" color="text.secondary" sx={{ mb: 4 }}>
        Import contacts from HubSpot, LinkedIn connections, and Gmail contacts. Enrich them with social profiles and company data.
      </Typography>

      {/* Import Type Tabs */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 4 }}>
        <Tabs value={tabValue} onChange={(e, newValue) => setTabValue(newValue)}>
          <Tab icon={<StatsIcon />} label="HubSpot CSV" />
          <Tab icon={<LinkedInIcon />} label="LinkedIn CSV" />
          <Tab icon={<EmailIcon />} label="Gmail Contacts" />
        </Tabs>
      </Box>

      {/* Statistics */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h4" color="primary" gutterBottom>
                {formatNumber(stats?.total)}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Total Contacts
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h4" color="success.main" gutterBottom>
                {formatNumber(stats?.enriched)}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Enriched Contacts
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h4" color="info.main" gutterBottom>
                {formatNumber(stats?.hubspotImports)}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                HubSpot Imports
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h4" color="warning.main" gutterBottom>
                {formatNumber(stats?.withLinkedIn)}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                With LinkedIn
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Tab Content */}
      {tabValue === 0 && (
        <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <UploadIcon sx={{ mr: 1, color: 'primary.main' }} />
                <Typography variant="h6">Import HubSpot Contacts</Typography>
              </Box>
              
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Upload your HubSpot contacts CSV export file. We'll automatically map and import all contact data.
              </Typography>

              <input
                accept=".csv"
                style={{ display: 'none' }}
                id="csv-upload"
                type="file"
                onChange={handleFileSelect}
              />
              <label htmlFor="csv-upload">
                <Button
                  variant="outlined"
                  component="span"
                  startIcon={<UploadIcon />}
                  fullWidth
                  sx={{ mb: 2 }}
                >
                  Select CSV File
                </Button>
              </label>

              {selectedFile && (
                <Box sx={{ mb: 2 }}>
                  <Typography variant="body2" color="text.secondary">
                    Selected: {selectedFile.name}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Size: {(selectedFile.size / 1024).toFixed(1)} KB
                  </Typography>
                </Box>
              )}

              {hubspotImportMutation.isLoading && (
                <Box sx={{ mb: 2 }}>
                  <LinearProgress variant="determinate" value={uploadProgress} />
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    Uploading and processing: {uploadProgress}%
                  </Typography>
                </Box>
              )}

              <Button
                variant="contained"
                onClick={handleImport}
                disabled={!selectedFile || hubspotImportMutation.isLoading}
                fullWidth
                startIcon={hubspotImportMutation.isLoading ? <CircularProgress size={20} /> : <UploadIcon />}
              >
                {hubspotImportMutation.isLoading ? 'Importing...' : 'Import Contacts'}
              </Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
      )}

      {/* LinkedIn Import Tab */}
      {tabValue === 1 && (
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} md={8}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <LinkedInIcon sx={{ mr: 1, color: '#0077B5' }} />
                  <Typography variant="h6">Import LinkedIn Connections</Typography>
                </Box>
                
                <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                  Upload your LinkedIn connections CSV file. Export from LinkedIn: Connections → Manage synced and imported contacts → Export contacts.
                </Typography>

                <input
                  accept=".csv"
                  style={{ display: 'none' }}
                  id="linkedin-upload"
                  type="file"
                  onChange={handleLinkedinFileSelect}
                />
                <label htmlFor="linkedin-upload">
                  <Button
                    variant="outlined"
                    component="span"
                    startIcon={<LinkedInIcon />}
                    fullWidth
                    sx={{ mb: 2 }}
                  >
                    Select LinkedIn CSV
                  </Button>
                </label>

                {linkedinFile && (
                  <Box sx={{ mb: 2 }}>
                    <Typography variant="body2" color="text.secondary">
                      Selected: {linkedinFile.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Size: {(linkedinFile.size / 1024).toFixed(1)} KB
                    </Typography>
                  </Box>
                )}

                {linkedinImportMutation.isLoading && (
                  <Box sx={{ mb: 2 }}>
                    <LinearProgress variant="determinate" value={uploadProgress} />
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                      Processing LinkedIn connections: {uploadProgress}%
                    </Typography>
                  </Box>
                )}

                <Button
                  variant="contained"
                  onClick={handleLinkedinImport}
                  disabled={!linkedinFile || linkedinImportMutation.isLoading}
                  fullWidth
                  startIcon={linkedinImportMutation.isLoading ? <CircularProgress size={20} /> : <LinkedInIcon />}
                  sx={{ bgcolor: '#0077B5', '&:hover': { bgcolor: '#005885' } }}
                >
                  {linkedinImportMutation.isLoading ? 'Importing...' : 'Import LinkedIn Connections'}
                </Button>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={4}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  📝 LinkedIn Export Guide
                </Typography>
                <List dense>
                  <ListItem>
                    <ListItemText primary="1. Go to LinkedIn.com → My Network" />
                  </ListItem>
                  <ListItem>
                    <ListItemText primary="2. Click 'Manage synced and imported contacts'" />
                  </ListItem>
                  <ListItem>
                    <ListItemText primary="3. Select 'Export contacts'" />
                  </ListItem>
                  <ListItem>
                    <ListItemText primary="4. Download the CSV file" />
                  </ListItem>
                  <ListItem>
                    <ListItemText primary="5. Upload it here" />
                  </ListItem>
                </List>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {/* Gmail Import Tab */}
      {tabValue === 2 && (
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} md={8}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <EmailIcon sx={{ mr: 1, color: '#EA4335' }} />
                  <Typography variant="h6">Import Gmail Contacts</Typography>
                </Box>
                
                <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                  Upload your Gmail contacts CSV or extract contacts from Gmail export (MBOX file). We'll find email addresses and create contact profiles.
                </Typography>

                <input
                  accept=".csv,.mbox"
                  style={{ display: 'none' }}
                  id="gmail-upload"
                  type="file"
                  onChange={handleGmailFileSelect}
                />
                <label htmlFor="gmail-upload">
                  <Button
                    variant="outlined"
                    component="span"
                    startIcon={<EmailIcon />}
                    fullWidth
                    sx={{ mb: 2 }}
                  >
                    Select Gmail File (CSV/MBOX)
                  </Button>
                </label>

                {gmailFile && (
                  <Box sx={{ mb: 2 }}>
                    <Typography variant="body2" color="text.secondary">
                      Selected: {gmailFile.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Size: {(gmailFile.size / 1024).toFixed(1)} KB
                    </Typography>
                  </Box>
                )}

                {gmailImportMutation.isLoading && (
                  <Box sx={{ mb: 2 }}>
                    <LinearProgress variant="determinate" value={uploadProgress} />
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                      Processing email contacts: {uploadProgress}%
                    </Typography>
                  </Box>
                )}

                <Button
                  variant="contained"
                  onClick={handleGmailImport}
                  disabled={!gmailFile || gmailImportMutation.isLoading}
                  fullWidth
                  startIcon={gmailImportMutation.isLoading ? <CircularProgress size={20} /> : <EmailIcon />}
                  sx={{ bgcolor: '#EA4335', '&:hover': { bgcolor: '#D33B2C' } }}
                >
                  {gmailImportMutation.isLoading ? 'Processing...' : 'Extract Email Contacts'}
                </Button>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={4}>
            <Card>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  📧 Gmail Export Options
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  <strong>Option 1: Google Contacts CSV</strong>
                </Typography>
                <List dense sx={{ mb: 2 }}>
                  <ListItem>
                    <ListItemText primary="1. Go to contacts.google.com" />
                  </ListItem>
                  <ListItem>
                    <ListItemText primary="2. Select contacts → Export" />
                  </ListItem>
                  <ListItem>
                    <ListItemText primary="3. Choose 'Google CSV' format" />
                  </ListItem>
                </List>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                  <strong>Option 2: Gmail Takeout</strong>
                </Typography>
                <List dense>
                  <ListItem>
                    <ListItemText primary="1. Go to takeout.google.com" />
                  </ListItem>
                  <ListItem>
                    <ListItemText primary="2. Select 'Mail' → Download" />
                  </ListItem>
                  <ListItem>
                    <ListItemText primary="3. Upload the MBOX file" />
                  </ListItem>
                </List>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      )}

      {/* Enrich Existing Contacts - Always Visible */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <EnrichIcon sx={{ mr: 1, color: 'secondary.main' }} />
                <Typography variant="h6">Enrich Existing Contacts</Typography>
              </Box>
              
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                Enrich your existing contacts with social profiles, company data, email verification, and more.
              </Typography>

              <List dense sx={{ mb: 2 }}>
                <ListItem>
                  <ListItemIcon>
                    <CheckCircle color="success" fontSize="small" />
                  </ListItemIcon>
                  <ListItemText primary="LinkedIn profile discovery" />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <CheckCircle color="success" fontSize="small" />
                  </ListItemIcon>
                  <ListItemText primary="Email verification" />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <CheckCircle color="success" fontSize="small" />
                  </ListItemIcon>
                  <ListItemText primary="Company information" />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <CheckCircle color="success" fontSize="small" />
                  </ListItemIcon>
                  <ListItemText primary="Social media profiles" />
                </ListItem>
              </List>

              <Button
                variant="contained"
                color="secondary"
                onClick={handleEnrich}
                disabled={enrichMutation.isLoading || !stats?.total}
                fullWidth
                startIcon={enrichMutation.isLoading ? <CircularProgress size={20} /> : <EnrichIcon />}
              >
                {enrichMutation.isLoading ? 'Enriching...' : 'Enrich All Contacts'}
              </Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Results */}
      {importResults && (
        <Card sx={{ mb: 4 }}>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              📈 Processing Results
            </Typography>
            
            <Grid container spacing={2} sx={{ mb: 2 }}>
              <Grid item xs={12} sm={4}>
                <Box sx={{ textAlign: 'center' }}>
                  <Typography variant="h4" color="primary">
                    {importResults.imported || importResults.processed || 0}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {importResults.imported ? 'Imported' : 'Processed'}
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box sx={{ textAlign: 'center' }}>
                  <Typography variant="h4" color="success.main">
                    {importResults.enriched || 0}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Enriched
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box sx={{ textAlign: 'center' }}>
                  <Typography variant="h4" color="error.main">
                    {importResults.errors?.length || 0}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Errors
                  </Typography>
                </Box>
              </Grid>
            </Grid>

            {importResults.errors && importResults.errors.length > 0 && (
              <Alert severity="warning" sx={{ mt: 2 }}>
                <Typography variant="body2">
                  {importResults.errors.length} contacts had processing errors. 
                  Check your CSV format and try again for failed contacts.
                </Typography>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* Instructions */}
      <Card>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            📋 HubSpot Export Instructions
          </Typography>
          
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            To export your contacts from HubSpot:
          </Typography>

          <List dense>
            <ListItem>
              <ListItemText primary="1. Go to Contacts → Contacts in your HubSpot account" />
            </ListItem>
            <ListItem>
              <ListItemText primary="2. Click 'Actions' → 'Export'" />
            </ListItem>
            <ListItem>
              <ListItemText primary="3. Select 'All contacts' or filter as needed" />
            </ListItem>
            <ListItem>
              <ListItemText primary="4. Choose 'All properties' for maximum enrichment data" />
            </ListItem>
            <ListItem>
              <ListItemText primary="5. Download the CSV file and upload it here" />
            </ListItem>
          </List>

          <Divider sx={{ my: 2 }} />

          <Typography variant="body2" color="text.secondary">
            <strong>Supported fields:</strong> First Name, Last Name, Email, Phone, Company, Job Title, 
            Website, Industry, City, State, Country, Notes, HubSpot Score, Lifecycle Stage
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
};

export default Import;