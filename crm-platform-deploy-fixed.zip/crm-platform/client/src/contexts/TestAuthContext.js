import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);

  // Hardcoded test user for demo
  const testUser = {
    id: '68869f8c3b92a657e88cad35',
    email: 'test@crm.com',
    firstName: 'Test',
    lastName: 'User',
    integrations: {
      gmail: { connected: false },
      linkedin: { connected: false }
    }
  };

  const login = async (email, password) => {
    try {
      setLoading(true);
      
      // Check test credentials
      if (email === 'test@crm.com' && password === 'password123') {
        const token = 'demo-token-' + Date.now();
        localStorage.setItem('token', token);
        setUser(testUser);
        return { success: true };
      }
      
      return { 
        success: false, 
        error: 'Invalid credentials - use test@crm.com / password123' 
      };
    } catch (error) {
      return { 
        success: false, 
        error: 'Login failed - using demo mode' 
      };
    } finally {
      setLoading(false);
    }
  };

  const register = async (userData) => {
    try {
      setLoading(true);
      
      // Simulate registration
      const token = 'demo-token-' + Date.now();
      localStorage.setItem('token', token);
      
      const newUser = {
        id: 'demo-' + Date.now(),
        email: userData.email,
        firstName: userData.firstName,
        lastName: userData.lastName,
        integrations: {
          gmail: { connected: false },
          linkedin: { connected: false }
        }
      };
      
      setUser(newUser);
      return { success: true };
    } catch (error) {
      return { 
        success: false, 
        error: 'Registration failed - demo mode' 
      };
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  // Check for existing token on load
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token && token.startsWith('demo-token')) {
      setUser(testUser);
    }
    setLoading(false);
  }, []);

  const value = {
    user,
    loading,
    login,
    register,
    logout
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};