# 🚀 QUICK DEPLOYMENT GUIDE

Your CRM is 100% ready for deployment! Here are your options:

## Option 1: Railway (RECOMMENDED) - 5 Minutes ⚡

**Why Railway?** Perfect for full-stack apps with file uploads + database.

### Steps:
1. **Login to Railway**
   ```bash
   railway login
   ```

2. **Initialize and Deploy**
   ```bash
   railway init
   railway up
   ```

3. **Set Environment Variables** (Copy/paste all at once):
   ```bash
   railway variables set MONGODB_URI="mongodb+srv://bwthompson12:UE19J2xZwax5rKcQ@cluster0.o92hzj1.mongodb.net/crm?retryWrites=true&w=majority"
   railway variables set JWT_SECRET="crm-super-secret-jwt-key-2024-production"
   railway variables set GMAIL_CLIENT_ID="982439180230-l08qtfd6ahknct2fk75e0ie667ebeacj.apps.googleusercontent.com"
   railway variables set GMAIL_CLIENT_SECRET="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"
   railway variables set NODE_ENV="production"
   ```

4. **Get Your Live URL**
   ```bash
   railway domain
   ```

## Option 2: Render.com - Web Interface

1. Go to **render.com** → Sign up/Login
2. Click **"New Web Service"**
3. Connect your GitHub repo (or upload as ZIP)
4. Settings:
   - **Build Command**: `npm run build`
   - **Start Command**: `npm start`
   - **Environment**: Node
5. Add Environment Variables:
   ```
   MONGODB_URI=mongodb+srv://bwthompson12:UE19J2xZwax5rKcQ@cluster0.o92hzj1.mongodb.net/crm?retryWrites=true&w=majority
   JWT_SECRET=crm-super-secret-jwt-key-2024-production
   GMAIL_CLIENT_ID=982439180230-l08qtfd6ahknct2fk75e0ie667ebeacj.apps.googleusercontent.com
   GMAIL_CLIENT_SECRET=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
   NODE_ENV=production
   ```

## Option 3: Heroku

1. **Install Heroku CLI** and login
2. **Create app**:
   ```bash
   heroku create your-crm-app-name
   ```
3. **Set environment variables**:
   ```bash
   heroku config:set MONGODB_URI="mongodb+srv://bwthompson12:UE19J2xZwax5rKcQ@cluster0.o92hzj1.mongodb.net/crm?retryWrites=true&w=majority"
   heroku config:set JWT_SECRET="crm-super-secret-jwt-key-2024-production"
   heroku config:set GMAIL_CLIENT_ID="982439180230-l08qtfd6ahknct2fk75e0ie667ebeacj.apps.googleusercontent.com"
   heroku config:set GMAIL_CLIENT_SECRET="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"
   ```
4. **Deploy**:
   ```bash
   git push heroku main
   ```

## 🎯 What You'll Have Live:

✅ **Complete CRM Dashboard** - Contact management, analytics, search
✅ **User Authentication** - Secure login/registration  
✅ **HubSpot CSV Import** - Upload and process your HubSpot contacts
✅ **LinkedIn CSV Import** - Import your LinkedIn connections
✅ **Gmail Contact Import** - Process Google Contacts CSV or Gmail MBOX files
✅ **Contact Enrichment** - Bulk enrich contacts with social profiles
✅ **File Upload Processing** - Real-time progress tracking
✅ **Mobile Responsive** - Works on all devices

## 📋 After Deployment:

1. **Register your account** on the live site
2. **Upload your HubSpot contacts** (Contacts → Export → CSV)
3. **Import LinkedIn connections** (My Network → Export contacts)
4. **Add Gmail contacts** (contacts.google.com → Export)
5. **Enrich all contacts** for social profiles and company data

Your CRM will be fully functional with all your contact data imported and enriched! 🔥

## Need Help?

- Railway has the best developer experience
- Render.com has a simple web interface  
- All platforms will work perfectly with your CRM

Choose Railway for fastest deployment! ⚡