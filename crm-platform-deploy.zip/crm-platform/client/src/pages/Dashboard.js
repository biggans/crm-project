import React from 'react';
import { useQuery } from 'react-query';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Button,
  List,
  ListItem,
  ListItemText,
  Chip
} from '@mui/material';
import {
  People as PeopleIcon,
  Business as BusinessIcon,
  TrendingUp as TrendingUpIcon,
  Email as EmailIcon
} from '@mui/icons-material';
import axios from '../axiosConfig';

const StatCard = ({ title, value, icon, color = 'primary' }) => (
  <Card>
    <CardContent>
      <Box sx={{ display: 'flex', alignItems: 'center' }}>
        <Box sx={{ color: `${color}.main`, mr: 2 }}>
          {icon}
        </Box>
        <Box>
          <Typography color="textSecondary" gutterBottom variant="h6">
            {title}
          </Typography>
          <Typography variant="h4" component="div">
            {value}
          </Typography>
        </Box>
      </Box>
    </CardContent>
  </Card>
);

const Dashboard = () => {
  const navigate = useNavigate();

  const { data: stats, isLoading: statsLoading } = useQuery(
    'contactStats',
    async () => {
      const response = await axios.get('/api/contacts/stats/summary');
      return response.data;
    }
  );

  const { data: recentContacts, isLoading: contactsLoading } = useQuery(
    'recentContacts',
    async () => {
      const response = await axios.get('/api/contacts?limit=5&sortBy=createdAt&sortOrder=desc');
      return response.data.contacts;
    }
  );

  if (statsLoading || contactsLoading) {
    return <Typography>Loading dashboard...</Typography>;
  }

  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom>
        Dashboard
      </Typography>

      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Total Contacts"
            value={stats?.totalContacts || 0}
            icon={<PeopleIcon fontSize="large" />}
            color="primary"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Companies"
            value={stats?.totalCompanies || 0}
            icon={<BusinessIcon fontSize="large" />}
            color="secondary"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Recent Interactions"
            value={stats?.recentInteractions || 0}
            icon={<EmailIcon fontSize="large" />}
            color="success"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="This Week"
            value={stats?.recentInteractions || 0}
            icon={<TrendingUpIcon fontSize="large" />}
            color="warning"
          />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6" component="h2">
                  Recent Contacts
                </Typography>
                <Button 
                  variant="outlined" 
                  size="small"
                  onClick={() => navigate('/contacts')}
                >
                  View All
                </Button>
              </Box>
              <List>
                {recentContacts?.map((contact) => (
                  <ListItem 
                    key={contact._id}
                    button
                    onClick={() => navigate(`/contacts/${contact._id}`)}
                  >
                    <ListItemText
                      primary={`${contact.firstName} ${contact.lastName}`}
                      secondary={
                        <Box>
                          <Typography variant="body2" color="text.secondary">
                            {contact.email}
                          </Typography>
                          {contact.company && (
                            <Typography variant="body2" color="text.secondary">
                              {contact.company}
                            </Typography>
                          )}
                        </Box>
                      }
                    />
                    <Chip 
                      label={contact.source} 
                      size="small" 
                      variant="outlined"
                    />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" component="h2" gutterBottom>
                Top Companies
              </Typography>
              <List>
                {stats?.topCompanies?.map((company, index) => (
                  <ListItem key={index}>
                    <ListItemText
                      primary={company._id}
                      secondary={`${company.count} contacts`}
                    />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Box sx={{ mt: 4 }}>
        <Card>
          <CardContent>
            <Typography variant="h6" component="h2" gutterBottom>
              Quick Actions
            </Typography>
            <Grid container spacing={2}>
              <Grid item>
                <Button 
                  variant="contained" 
                  onClick={() => navigate('/contacts/new')}
                >
                  Add New Contact
                </Button>
              </Grid>
              <Grid item>
                <Button 
                  variant="outlined"
                  onClick={() => navigate('/integrations')}
                >
                  Manage Integrations
                </Button>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Box>
    </Box>
  );
};

export default Dashboard;