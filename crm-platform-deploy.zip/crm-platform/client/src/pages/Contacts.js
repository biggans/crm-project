import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from 'react-query';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  TextField,
  Grid,
  Avatar,
  Chip,
  IconButton,
  InputAdornment,
  Pagination,
  FormControl,
  InputLabel,
  Select,
  MenuItem
} from '@mui/material';
import {
  Search as SearchIcon,
  Add as AddIcon,
  Email as EmailIcon,
  Business as BusinessIcon,
  LinkedIn as LinkedInIcon
} from '@mui/icons-material';
import axios from '../axiosConfig';

const Contacts = () => {
  const navigate = useNavigate();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [company, setCompany] = useState('');
  const [priority, setPriority] = useState('');
  const [sortBy, setSortBy] = useState('lastContact');

  const { data, isLoading, error } = useQuery(
    ['contacts', page, search, company, priority, sortBy],
    async () => {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '20',
        sortBy,
        sortOrder: 'desc'
      });
      
      if (search) params.append('search', search);
      if (company) params.append('company', company);
      if (priority) params.append('priority', priority);
      
      const response = await axios.get(`/api/contacts?${params}`);
      return response.data;
    },
    { keepPreviousData: true }
  );

  const getInitials = (firstName, lastName) => {
    return `${firstName?.[0] || ''}${lastName?.[0] || ''}`.toUpperCase();
  };

  const formatDate = (date) => {
    if (!date) return 'Never';
    return new Date(date).toLocaleDateString();
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'error';
      case 'medium': return 'warning';
      case 'low': return 'success';
      default: return 'default';
    }
  };

  if (isLoading) return <Typography>Loading contacts...</Typography>;
  if (error) return <Typography color="error">Error loading contacts</Typography>;

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" component="h1">
          Contacts ({data?.total || 0})
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => navigate('/contacts/new')}
        >
          Add Contact
        </Button>
      </Box>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={12} md={4}>
          <TextField
            fullWidth
            placeholder="Search contacts..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
          />
        </Grid>
        <Grid item xs={12} md={2}>
          <TextField
            fullWidth
            placeholder="Company"
            value={company}
            onChange={(e) => setCompany(e.target.value)}
          />
        </Grid>
        <Grid item xs={12} md={2}>
          <FormControl fullWidth>
            <InputLabel>Priority</InputLabel>
            <Select
              value={priority}
              label="Priority"
              onChange={(e) => setPriority(e.target.value)}
            >
              <MenuItem value="">All</MenuItem>
              <MenuItem value="high">High</MenuItem>
              <MenuItem value="medium">Medium</MenuItem>
              <MenuItem value="low">Low</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} md={2}>
          <FormControl fullWidth>
            <InputLabel>Sort By</InputLabel>
            <Select
              value={sortBy}
              label="Sort By"
              onChange={(e) => setSortBy(e.target.value)}
            >
              <MenuItem value="lastContact">Last Contact</MenuItem>
              <MenuItem value="firstName">Name</MenuItem>
              <MenuItem value="company">Company</MenuItem>
              <MenuItem value="createdAt">Date Added</MenuItem>
            </Select>
          </FormControl>
        </Grid>
      </Grid>

      <Grid container spacing={2}>
        {data?.contacts?.map((contact) => (
          <Grid item xs={12} md={6} lg={4} key={contact._id}>
            <Card 
              sx={{ 
                cursor: 'pointer',
                '&:hover': { elevation: 4 }
              }}
              onClick={() => navigate(`/contacts/${contact._id}`)}
            >
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Avatar sx={{ mr: 2, bgcolor: 'primary.main' }}>
                    {getInitials(contact.firstName, contact.lastName)}
                  </Avatar>
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="h6" component="div">
                      {contact.firstName} {contact.lastName}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {contact.position}
                    </Typography>
                  </Box>
                  <Chip 
                    label={contact.priority} 
                    color={getPriorityColor(contact.priority)}
                    size="small"
                  />
                </Box>

                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <EmailIcon sx={{ mr: 1, fontSize: 16 }} color="action" />
                  <Typography variant="body2" color="text.secondary">
                    {contact.email}
                  </Typography>
                </Box>

                {contact.company && (
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <BusinessIcon sx={{ mr: 1, fontSize: 16 }} color="action" />
                    <Typography variant="body2" color="text.secondary">
                      {contact.company}
                    </Typography>
                  </Box>
                )}

                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2 }}>
                  <Typography variant="caption" color="text.secondary">
                    Last contact: {formatDate(contact.lastContact)}
                  </Typography>
                  <Box>
                    {contact.socialProfiles?.linkedin?.url && (
                      <IconButton size="small" color="primary">
                        <LinkedInIcon fontSize="small" />
                      </IconButton>
                    )}
                  </Box>
                </Box>

                {contact.tags && contact.tags.length > 0 && (
                  <Box sx={{ mt: 1 }}>
                    {contact.tags.slice(0, 3).map((tag, index) => (
                      <Chip 
                        key={index}
                        label={tag} 
                        size="small" 
                        variant="outlined" 
                        sx={{ mr: 0.5, mb: 0.5 }}
                      />
                    ))}
                    {contact.tags.length > 3 && (
                      <Typography variant="caption" color="text.secondary">
                        +{contact.tags.length - 3} more
                      </Typography>
                    )}
                  </Box>
                )}
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {data?.totalPages > 1 && (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <Pagination
            count={data.totalPages}
            page={page}
            onChange={(event, value) => setPage(value)}
            color="primary"
          />
        </Box>
      )}
    </Box>
  );
};

export default Contacts;