const csvParser = require('csv-parser');
const fs = require('fs');
const Contact = require('../models/Contact');

class LinkedInImportService {
  async importFromCSV(filePath, userId) {
    return new Promise((resolve, reject) => {
      const contacts = [];
      const results = {
        processed: 0,
        imported: 0,
        enriched: 0,
        errors: []
      };

      fs.createReadStream(filePath)
        .pipe(csvParser())
        .on('data', (row) => {
          try {
            // LinkedIn CSV format mapping
            const contact = this.mapLinkedInFields(row, userId);
            if (contact) {
              contacts.push(contact);
              results.processed++;
            }
          } catch (error) {
            results.errors.push({
              row: results.processed + 1,
              error: error.message,
              data: row
            });
          }
        })
        .on('end', async () => {
          try {
            // Bulk insert/update contacts
            for (const contactData of contacts) {
              try {
                await this.saveContact(contactData);
                results.imported++;
              } catch (error) {
                results.errors.push({
                  contact: contactData.email || contactData.firstName + ' ' + contactData.lastName,
                  error: error.message
                });
              }
            }

            resolve(results);
          } catch (error) {
            reject(error);
          }
        })
        .on('error', (error) => {
          reject(error);
        });
    });
  }

  mapLinkedInFields(row, userId) {
    // Common LinkedIn CSV field mappings
    const firstNameFields = ['First Name', 'Given Name', 'first_name', 'firstName'];
    const lastNameFields = ['Last Name', 'Family Name', 'last_name', 'lastName'];
    const emailFields = ['Email Address', 'Email', 'email_address', 'email'];
    const companyFields = ['Company', 'Organization', 'company', 'current_company'];
    const positionFields = ['Position', 'Title', 'Job Title', 'position', 'job_title'];
    const connectionDateFields = ['Connected On', 'Connection Date', 'connected_on'];

    // Find values using different possible field names
    const firstName = this.findFieldValue(row, firstNameFields);
    const lastName = this.findFieldValue(row, lastNameFields);
    const email = this.findFieldValue(row, emailFields);
    const company = this.findFieldValue(row, companyFields);
    const position = this.findFieldValue(row, positionFields);
    const connectionDate = this.findFieldValue(row, connectionDateFields);

    // Must have at least name or email
    if (!firstName && !lastName && !email) {
      return null;
    }

    const contact = {
      userId,
      firstName: firstName || '',
      lastName: lastName || '',
      email: email || '',
      company: company || '',
      jobTitle: position || '',
      source: 'linkedin',
      tags: ['linkedin-connection'],
      socialProfiles: {
        linkedin: row['Profile URL'] || row['LinkedIn URL'] || row['url'] || ''
      },
      notes: connectionDate ? `Connected on LinkedIn: ${connectionDate}` : 'LinkedIn connection',
      createdAt: new Date(),
      updatedAt: new Date()
    };

    return contact;
  }

  findFieldValue(row, fieldNames) {
    for (const fieldName of fieldNames) {
      if (row[fieldName] && row[fieldName].trim()) {
        return row[fieldName].trim();
      }
    }
    return '';
  }

  async saveContact(contactData) {
    try {
      // Check if contact already exists (by email or LinkedIn profile)
      let existingContact = null;
      
      if (contactData.email) {
        existingContact = await Contact.findOne({
          userId: contactData.userId,
          email: contactData.email
        });
      }

      if (!existingContact && contactData.socialProfiles?.linkedin) {
        existingContact = await Contact.findOne({
          userId: contactData.userId,
          'socialProfiles.linkedin': contactData.socialProfiles.linkedin
        });
      }

      if (existingContact) {
        // Update existing contact with LinkedIn data
        const updatedData = {
          ...contactData,
          tags: [...new Set([...(existingContact.tags || []), ...contactData.tags])],
          socialProfiles: {
            ...existingContact.socialProfiles,
            ...contactData.socialProfiles
          },
          updatedAt: new Date()
        };

        // Only update fields that are empty or add new information
        if (!existingContact.company && contactData.company) {
          updatedData.company = contactData.company;
        }
        if (!existingContact.jobTitle && contactData.jobTitle) {
          updatedData.jobTitle = contactData.jobTitle;
        }

        await Contact.findByIdAndUpdate(existingContact._id, updatedData);
        return existingContact;
      } else {
        // Create new contact
        const newContact = new Contact(contactData);
        await newContact.save();
        return newContact;
      }
    } catch (error) {
      console.error('Error saving LinkedIn contact:', error);
      throw error;
    }
  }
}

module.exports = LinkedInImportService;