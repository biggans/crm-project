const Contact = require('../models/Contact');
const csv = require('csv-parser');
const fs = require('fs');

class HubSpotImportService {
  constructor() {
    this.enrichmentServices = {
      clearbit: process.env.CLEARBIT_API_KEY,
      hunter: process.env.HUNTER_API_KEY,
      pipl: process.env.PIPL_API_KEY
    };
  }

  async importFromCSV(filePath, userId) {
    const contacts = [];
    const results = {
      imported: 0,
      enriched: 0,
      errors: []
    };

    return new Promise((resolve, reject) => {
      fs.createReadStream(filePath)
        .pipe(csv())
        .on('data', (row) => {
          contacts.push(this.mapHubSpotContact(row));
        })
        .on('end', async () => {
          for (const contactData of contacts) {
            try {
              // Check if contact already exists
              const existingContact = await Contact.findOne({ email: contactData.email });
              
              if (!existingContact) {
                // Enrich contact data
                const enrichedData = await this.enrichContact(contactData);
                
                // Save to database
                const contact = new Contact({
                  ...enrichedData,
                  source: 'hubspot',
                  userId: userId
                });
                
                await contact.save();
                results.imported++;
                
                if (enrichedData.enriched) {
                  results.enriched++;
                }
              }
            } catch (error) {
              results.errors.push({
                email: contactData.email,
                error: error.message
              });
            }
          }
          
          resolve(results);
        })
        .on('error', reject);
    });
  }

  mapHubSpotContact(row) {
    // Map HubSpot CSV fields to our contact schema
    return {
      firstName: row['First Name'] || row['first_name'] || '',
      lastName: row['Last Name'] || row['last_name'] || '',
      email: row['Email'] || row['email'] || '',
      phone: row['Phone Number'] || row['phone'] || '',
      company: row['Company Name'] || row['company'] || '',
      position: row['Job Title'] || row['position'] || row['title'] || '',
      website: row['Website URL'] || row['website'] || '',
      industry: row['Industry'] || row['industry'] || '',
      city: row['City'] || row['city'] || '',
      state: row['State/Region'] || row['state'] || '',
      country: row['Country'] || row['country'] || '',
      notes: row['Notes'] || row['notes'] || '',
      hubspotId: row['Record ID'] || row['hubspot_id'] || '',
      lastActivity: row['Last Activity Date'] || null,
      leadScore: row['HubSpot Score'] || row['lead_score'] || 0,
      lifecycle: row['Lifecycle Stage'] || row['lifecycle'] || '',
      tags: []
    };
  }

  async enrichContact(contactData) {
    let enriched = false;
    const enrichments = {};

    try {
      // Enrich with email validation and social profiles
      if (contactData.email) {
        const emailEnrichment = await this.enrichWithEmail(contactData.email);
        if (emailEnrichment) {
          enrichments.socialProfiles = emailEnrichment.socialProfiles;
          enrichments.verifiedEmail = emailEnrichment.verified;
          enriched = true;
        }
      }

      // Enrich with company information
      if (contactData.company) {
        const companyEnrichment = await this.enrichWithCompany(contactData.company);
        if (companyEnrichment) {
          enrichments.companyInfo = companyEnrichment;
          enriched = true;
        }
      }

      // Enrich with LinkedIn profile
      if (contactData.firstName && contactData.lastName && contactData.company) {
        const linkedinProfile = await this.findLinkedInProfile(
          contactData.firstName, 
          contactData.lastName, 
          contactData.company
        );
        if (linkedinProfile) {
          enrichments.socialProfiles = {
            ...enrichments.socialProfiles,
            linkedin: linkedinProfile
          };
          enriched = true;
        }
      }

      return {
        ...contactData,
        ...enrichments,
        enriched,
        enrichmentDate: new Date()
      };
    } catch (error) {
      console.error('Enrichment error:', error);
      return { ...contactData, enriched: false };
    }
  }

  async enrichWithEmail(email) {
    // Hunter.io email verification and social profile discovery
    if (!this.enrichmentServices.hunter) return null;

    try {
      const response = await fetch(`https://api.hunter.io/v2/email-verifier?email=${email}&api_key=${this.enrichmentServices.hunter}`);
      const data = await response.json();
      
      if (data.data) {
        return {
          verified: data.data.result === 'deliverable',
          socialProfiles: {
            linkedin: data.data.sources?.find(s => s.domain === 'linkedin.com')?.uri || null,
            twitter: data.data.sources?.find(s => s.domain === 'twitter.com')?.uri || null
          }
        };
      }
    } catch (error) {
      console.error('Hunter.io enrichment error:', error);
    }
    
    return null;
  }

  async enrichWithCompany(companyName) {
    // Clearbit company enrichment
    if (!this.enrichmentServices.clearbit) return null;

    try {
      const response = await fetch(`https://company.clearbit.com/v1/domains/find?name=${encodeURIComponent(companyName)}`, {
        headers: {
          'Authorization': `Bearer ${this.enrichmentServices.clearbit}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        return {
          domain: data.domain,
          description: data.description,
          industry: data.category?.industry,
          employees: data.metrics?.employees,
          founded: data.foundedYear,
          location: data.geo?.city + ', ' + data.geo?.country,
          logo: data.logo,
          linkedin: data.linkedin?.handle,
          twitter: data.twitter?.handle
        };
      }
    } catch (error) {
      console.error('Clearbit enrichment error:', error);
    }
    
    return null;
  }

  async findLinkedInProfile(firstName, lastName, company) {
    // Simple LinkedIn profile URL construction (basic)
    const name = `${firstName}-${lastName}`.toLowerCase().replace(/\s+/g, '-');
    const profileUrl = `https://linkedin.com/in/${name}`;
    
    // In production, you'd use LinkedIn API or a service like PhantomBuster
    return {
      url: profileUrl,
      estimated: true,
      lastSync: new Date()
    };
  }

  async bulkEnrichExistingContacts(userId) {
    const contacts = await Contact.find({ 
      userId, 
      $or: [
        { enriched: { $ne: true } },
        { enriched: { $exists: false } }
      ]
    });

    const results = {
      processed: 0,
      enriched: 0,
      errors: []
    };

    for (const contact of contacts) {
      try {
        const enrichedData = await this.enrichContact(contact.toObject());
        
        if (enrichedData.enriched) {
          await Contact.findByIdAndUpdate(contact._id, {
            ...enrichedData,
            enrichmentDate: new Date()
          });
          results.enriched++;
        }
        
        results.processed++;
      } catch (error) {
        results.errors.push({
          contactId: contact._id,
          email: contact.email,
          error: error.message
        });
      }
    }

    return results;
  }
}

module.exports = HubSpotImportService;