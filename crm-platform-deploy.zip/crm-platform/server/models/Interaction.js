const mongoose = require('mongoose');

const interactionSchema = new mongoose.Schema({
  contact: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Contact',
    required: true
  },
  type: {
    type: String,
    enum: ['email', 'call', 'meeting', 'linkedin_message', 'linkedin_connection', 'note'],
    required: true
  },
  direction: {
    type: String,
    enum: ['inbound', 'outbound'],
    required: true
  },
  subject: {
    type: String,
    trim: true
  },
  content: {
    type: String,
    trim: true
  },
  platform: {
    type: String,
    enum: ['gmail', 'linkedin', 'phone', 'manual'],
    required: true
  },
  externalId: {
    type: String,
    trim: true
  },
  metadata: {
    messageId: String,
    threadId: String,
    attachments: [String],
    location: String,
    duration: Number
  },
  date: {
    type: Date,
    required: true,
    default: Date.now
  },
  reminder: {
    date: Date,
    completed: {
      type: Boolean,
      default: false
    }
  }
}, {
  timestamps: true
});

interactionSchema.index({ contact: 1, date: -1 });
interactionSchema.index({ type: 1 });
interactionSchema.index({ platform: 1 });
interactionSchema.index({ date: -1 });

module.exports = mongoose.model('Interaction', interactionSchema);