const mongoose = require('mongoose');

const contactSchema = new mongoose.Schema({
  firstName: {
    type: String,
    required: true,
    trim: true
  },
  lastName: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true
  },
  phone: {
    type: String,
    trim: true
  },
  company: {
    type: String,
    trim: true
  },
  position: {
    type: String,
    trim: true
  },
  socialProfiles: {
    linkedin: {
      url: String,
      profileId: String,
      lastSync: Date
    },
    twitter: {
      url: String,
      handle: String,
      lastSync: Date
    },
    instagram: {
      url: String,
      handle: String,
      lastSync: Date
    }
  },
  tags: [{
    type: String,
    trim: true
  }],
  notes: {
    type: String,
    trim: true
  },
  lastContact: {
    type: Date
  },
  contactFrequency: {
    type: String,
    enum: ['daily', 'weekly', 'monthly', 'quarterly', 'yearly'],
    default: 'monthly'
  },
  priority: {
    type: String,
    enum: ['low', 'medium', 'high'],
    default: 'medium'
  },
  source: {
    type: String,
    enum: ['gmail', 'linkedin', 'manual', 'import'],
    required: true
  },
  status: {
    type: String,
    enum: ['active', 'inactive', 'archived'],
    default: 'active'
  }
}, {
  timestamps: true
});

contactSchema.index({ email: 1 });
contactSchema.index({ company: 1 });
contactSchema.index({ tags: 1 });
contactSchema.index({ lastContact: 1 });

module.exports = mongoose.model('Contact', contactSchema);