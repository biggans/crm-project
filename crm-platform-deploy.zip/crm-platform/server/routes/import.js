const express = require('express');
const multer = require('multer');
const path = require('path');
const HubSpotImportService = require('../services/hubspotImport');
const LinkedInImportService = require('../services/linkedinImport');
const GmailImportService = require('../services/gmailImport');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, 'hubspot-' + Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  fileFilter: function (req, file, cb) {
    const ext = path.extname(file.originalname).toLowerCase();
    if (ext !== '.csv' && ext !== '.mbox') {
      return cb(new Error('Only CSV and MBOX files are allowed'));
    }
    cb(null, true);
  },
  limits: {
    fileSize: 50 * 1024 * 1024 // 50MB limit for MBOX files
  }
});

// Import HubSpot contacts from CSV
router.post('/hubspot', upload.single('csvFile'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No CSV file provided' });
    }

    const { userId } = req.body;
    if (!userId) {
      return res.status(400).json({ error: 'User ID required' });
    }

    const importService = new HubSpotImportService();
    const results = await importService.importFromCSV(req.file.path, userId);

    // Clean up uploaded file
    require('fs').unlinkSync(req.file.path);

    res.json({
      success: true,
      message: 'HubSpot contacts imported successfully',
      results
    });
  } catch (error) {
    console.error('Import error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Enrich existing contacts
router.post('/enrich', async (req, res) => {
  try {
    const { userId } = req.body;
    if (!userId) {
      return res.status(400).json({ error: 'User ID required' });
    }

    const importService = new HubSpotImportService();
    const results = await importService.bulkEnrichExistingContacts(userId);

    res.json({
      success: true,
      message: 'Contact enrichment completed',
      results
    });
  } catch (error) {
    console.error('Enrichment error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get import status and statistics
router.get('/stats/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const Contact = require('../models/Contact');

    const stats = await Contact.aggregate([
      { $match: { userId } },
      {
        $group: {
          _id: null,
          total: { $sum: 1 },
          enriched: { $sum: { $cond: [{ $eq: ['$enriched', true] }, 1, 0] } },
          hubspotImports: { $sum: { $cond: [{ $eq: ['$source', 'hubspot'] }, 1, 0] } },
          withLinkedIn: { $sum: { $cond: [{ $exists: ['$socialProfiles.linkedin'] }, 1, 0] } },
          withTwitter: { $sum: { $cond: [{ $exists: ['$socialProfiles.twitter'] }, 1, 0] } }
        }
      }
    ]);

    const result = stats[0] || {
      total: 0,
      enriched: 0,
      hubspotImports: 0,
      withLinkedIn: 0,
      withTwitter: 0
    };

    res.json({
      success: true,
      stats: result
    });
  } catch (error) {
    console.error('Stats error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Import LinkedIn connections from CSV
router.post('/linkedin', upload.single('csvFile'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No CSV file provided' });
    }

    const { userId } = req.body;
    if (!userId) {
      return res.status(400).json({ error: 'User ID required' });
    }

    const importService = new LinkedInImportService();
    const results = await importService.importFromCSV(req.file.path, userId);

    // Clean up uploaded file
    require('fs').unlinkSync(req.file.path);

    res.json({
      success: true,
      message: 'LinkedIn connections imported successfully',
      results
    });
  } catch (error) {
    console.error('LinkedIn import error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Import Gmail contacts from CSV or MBOX
router.post('/gmail', upload.single('emailFile'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file provided' });
    }

    const { userId } = req.body;
    if (!userId) {
      return res.status(400).json({ error: 'User ID required' });
    }

    const importService = new GmailImportService();
    let results;
    
    if (req.file.originalname.endsWith('.mbox')) {
      results = await importService.importFromMbox(req.file.path, userId);
    } else {
      results = await importService.importFromCSV(req.file.path, userId);
    }

    // Clean up uploaded file
    require('fs').unlinkSync(req.file.path);

    res.json({
      success: true,
      message: 'Gmail contacts imported successfully',
      results
    });
  } catch (error) {
    console.error('Gmail import error:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;