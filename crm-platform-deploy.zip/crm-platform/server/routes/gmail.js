const express = require('express');
const router = express.Router();
const GmailService = require('../services/gmailService');
const User = require('../models/User');

router.get('/auth', async (req, res) => {
  try {
    const gmailService = new GmailService();
    const authUrl = gmailService.getAuthUrl();
    res.json({ authUrl });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/callback', async (req, res) => {
  try {
    const { code, state } = req.query;
    const userId = state;
    
    if (!code) {
      return res.redirect('http://localhost:3000/integrations?error=oauth_cancelled');
    }
    
    const gmailService = new GmailService();
    const tokens = await gmailService.getAccessToken(code);
    
    await User.findByIdAndUpdate(userId, {
      'integrations.gmail.connected': true,
      'integrations.gmail.accessToken': tokens.access_token,
      'integrations.gmail.refreshToken': tokens.refresh_token,
      'integrations.gmail.lastSync': new Date()
    });

    res.redirect('http://localhost:3000/integrations?success=gmail_connected');
  } catch (error) {
    res.redirect('http://localhost:3000/integrations?error=gmail_failed');
  }
});

router.post('/callback', async (req, res) => {
  try {
    const { code, userId } = req.body;
    
    const gmailService = new GmailService();
    const tokens = await gmailService.getAccessToken(code);
    
    await User.findByIdAndUpdate(userId, {
      'integrations.gmail.connected': true,
      'integrations.gmail.accessToken': tokens.access_token,
      'integrations.gmail.refreshToken': tokens.refresh_token,
      'integrations.gmail.lastSync': new Date()
    });

    res.json({ success: true, message: 'Gmail connected successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/sync', async (req, res) => {
  try {
    const { userId } = req.body;
    
    const user = await User.findById(userId);
    if (!user || !user.integrations.gmail.connected) {
      return res.status(400).json({ error: 'Gmail not connected' });
    }

    const gmailService = new GmailService();
    await gmailService.setCredentials({
      access_token: user.integrations.gmail.accessToken,
      refresh_token: user.integrations.gmail.refreshToken
    });

    const result = await gmailService.syncEmails(userId, user.integrations.gmail.lastSync);
    
    await User.findByIdAndUpdate(userId, {
      'integrations.gmail.lastSync': new Date()
    });

    res.json({ 
      success: true, 
      message: 'Gmail sync completed',
      ...result 
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/status/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findById(userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      connected: user.integrations.gmail.connected,
      lastSync: user.integrations.gmail.lastSync
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;