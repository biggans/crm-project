const express = require('express');
const router = express.Router();
const LinkedInService = require('../services/linkedinService');
const User = require('../models/User');

router.get('/auth', async (req, res) => {
  try {
    const linkedinService = new LinkedInService();
    const authUrl = linkedinService.getAuthUrl();
    res.json({ authUrl });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/callback', async (req, res) => {
  try {
    const { code, userId } = req.body;
    
    const linkedinService = new LinkedInService();
    const tokenData = await linkedinService.getAccessToken(code);
    const userProfile = await linkedinService.getUserProfile(tokenData.access_token);
    
    await User.findByIdAndUpdate(userId, {
      'integrations.linkedin.connected': true,
      'integrations.linkedin.accessToken': tokenData.access_token,
      'integrations.linkedin.profileId': userProfile.id,
      'integrations.linkedin.lastSync': new Date()
    });

    res.json({ 
      success: true, 
      message: 'LinkedIn connected successfully',
      profile: userProfile
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/sync', async (req, res) => {
  try {
    const { userId } = req.body;
    
    const user = await User.findById(userId);
    if (!user || !user.integrations.linkedin.connected) {
      return res.status(400).json({ error: 'LinkedIn not connected' });
    }

    const linkedinService = new LinkedInService();
    const result = await linkedinService.syncConnections(userId, user.integrations.linkedin.accessToken);
    
    await User.findByIdAndUpdate(userId, {
      'integrations.linkedin.lastSync': new Date()
    });

    res.json({ 
      success: true, 
      message: 'LinkedIn sync completed',
      ...result 
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/search', async (req, res) => {
  try {
    const { userId, keywords, start = 0, count = 25 } = req.query;
    
    const user = await User.findById(userId);
    if (!user || !user.integrations.linkedin.connected) {
      return res.status(400).json({ error: 'LinkedIn not connected' });
    }

    const linkedinService = new LinkedInService();
    const searchResults = await linkedinService.searchPeople(
      user.integrations.linkedin.accessToken,
      keywords,
      parseInt(start),
      parseInt(count)
    );

    res.json({ 
      success: true,
      results: searchResults
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/status/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findById(userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      connected: user.integrations.linkedin.connected,
      profileId: user.integrations.linkedin.profileId,
      lastSync: user.integrations.linkedin.lastSync
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;