#!/bin/bash

echo "🚀 CRM Deployment Script for Railway"
echo "======================================"

# Check if Railway CLI is installed
if ! command -v railway &> /dev/null; then
    echo "📦 Installing Railway CLI..."
    npm install -g @railway/cli
fi

echo "🔑 Please run 'railway login' first, then run this script again"
echo ""
echo "After logging in, this script will:"
echo "1. Initialize Railway project"
echo "2. Deploy your CRM"
echo "3. Set environment variables"
echo "4. Give you the live URL"
echo ""

# Check if user is logged in
if railway whoami &> /dev/null; then
    echo "✅ Already logged in to Railway"
    
    echo "🚀 Initializing Railway project..."
    railway init
    
    echo "📤 Deploying CRM..."
    railway up
    
    echo "🔧 Setting environment variables..."
    railway variables set MONGODB_URI="mongodb+srv://bwthompson12:UE19J2xZwax5rKcQ@cluster0.o92hzj1.mongodb.net/crm?retryWrites=true&w=majority"
    railway variables set JWT_SECRET="crm-super-secret-jwt-key-2024-production"
    railway variables set GMAIL_CLIENT_ID="982439180230-l08qtfd6ahknct2fk75e0ie667ebeacj.apps.googleusercontent.com"
    railway variables set GMAIL_CLIENT_SECRET="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"
    railway variables set NODE_ENV="production"
    
    echo ""
    echo "🎉 Deployment Complete!"
    echo "Your CRM is live at:"
    railway domain
    
    echo ""
    echo "📋 Next Steps:"
    echo "1. Visit your live CRM URL"
    echo "2. Register your account"
    echo "3. Start importing your contacts!"
    
else
    echo "❌ Not logged in to Railway"
    echo "Please run: railway login"
    echo "Then run this script again"
fi