# 📱 Deploy Frontend to Netlify (Limited Features)

If you only want to deploy the frontend interface to Netlify, follow these steps. Note that file upload and database features will require a separate backend deployment.

## Quick Netlify Deployment

### 1. Install Netlify CLI
```bash
npm install -g netlify-cli
```

### 2. Build the React App
```bash
cd client
npm run build
```

### 3. Deploy to Netlify
```bash
netlify deploy --prod --dir=build
```

### 4. Connect to External Backend
Update the API base URL in your React app to point to your Railway/Render backend:

```javascript
// In client/src/axiosConfig.js
const baseURL = 'https://your-railway-app.railway.app/api';
```

## ⚠️ Important Limitations

When using Netlify for frontend only:

❌ **No File Uploads**: CSV imports won't work without backend
❌ **No Database**: Contact storage requires external backend  
❌ **No Authentication**: Login/register needs backend APIs
❌ **No Contact Management**: CRUD operations need backend

## 🔥 Recommended: Use Railway for Full-Stack

For complete functionality including:
- ✅ File uploads (HubSpot, LinkedIn, Gmail)
- ✅ Contact management and storage
- ✅ User authentication
- ✅ Contact enrichment

**Use Railway deployment instead** - see `DEPLOY_RAILWAY.md`

## If You Still Want Netlify + External Backend

1. Deploy backend to Railway/Render/Heroku
2. Deploy frontend to Netlify  
3. Update API endpoints in React app
4. Configure CORS on backend for Netlify domain

This gives you:
- ✅ Fast CDN frontend (Netlify)
- ✅ Full backend functionality (Railway)
- ✅ All CRM features working