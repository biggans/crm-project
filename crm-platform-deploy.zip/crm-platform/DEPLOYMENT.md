# CRM Platform Deployment Guide

Your CRM is ready for live deployment! Here are the deployment options:

## Option 1: Railway (Recommended)

1. **Install Railway CLI**:
   ```bash
   npm install -g @railway/cli
   ```

2. **Login to Railway**:
   ```bash
   railway login
   ```

3. **Deploy**:
   ```bash
   railway init
   railway up
   ```

4. **Set Environment Variables**:
   ```bash
   railway variables set MONGODB_URI="mongodb+srv://bwthompson12:UE19J2xZwax5rKcQ@cluster0.o92hzj1.mongodb.net/crm?retryWrites=true&w=majority"
   railway variables set JWT_SECRET="crm-super-secret-jwt-key-2024-production"
   railway variables set GMAIL_CLIENT_ID="982439180230-l08qtfd6ahknct2fk75e0ie667ebeacj.apps.googleusercontent.com"
   railway variables set GMAIL_CLIENT_SECRET="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"
   railway variables set NODE_ENV="production"
   ```

## Option 2: Heroku

1. **Install Heroku CLI** and login
2. **Create app**:
   ```bash
   heroku create your-crm-app-name
   ```
3. **Set environment variables**:
   ```bash
   heroku config:set MONGODB_URI="mongodb+srv://bwthompson12:UE19J2xZwax5rKcQ@cluster0.o92hzj1.mongodb.net/crm?retryWrites=true&w=majority"
   heroku config:set JWT_SECRET="crm-super-secret-jwt-key-2024-production"
   heroku config:set GMAIL_CLIENT_ID="982439180230-l08qtfd6ahknct2fk75e0ie667ebeacj.apps.googleusercontent.com"
   heroku config:set GMAIL_CLIENT_SECRET="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"
   ```
4. **Deploy**:
   ```bash
   git push heroku main
   ```

## Features Ready for Use

✅ **Complete CRM System**
- User authentication and registration
- Contact management and search
- Dashboard with analytics
- Social profile tracking

✅ **HubSpot Integration**
- CSV import functionality
- Contact enrichment with social profiles
- Bulk processing capabilities
- Import statistics and tracking

✅ **LinkedIn Integration** 
- CSV file upload for LinkedIn connections
- Automatic profile mapping and contact creation
- Connection date tracking
- LinkedIn profile URL preservation

✅ **Gmail Integration**
- CSV file upload from Google Contacts export
- MBOX file processing from Gmail Takeout
- Email address extraction and contact creation
- Automatic name parsing from email addresses

✅ **Contact Enrichment**
- Contact data enrichment with social profiles
- Bulk processing capabilities
- Email verification (Hunter.io integration ready)
- Company data enrichment (Clearbit integration ready)

## Next Steps After Deployment

1. **Upload Your Contact Data**: Use the Import & Enrich page to upload:
   - **HubSpot CSV**: Your exported HubSpot contacts
   - **LinkedIn CSV**: Your LinkedIn connections export
   - **Gmail Files**: Google Contacts CSV or Gmail Takeout MBOX files

2. **Export Instructions**:
   - **HubSpot**: Contacts → Export → All properties → CSV
   - **LinkedIn**: My Network → Manage synced contacts → Export contacts
   - **Gmail**: contacts.google.com → Export → Google CSV format
   - **Gmail Alternative**: takeout.google.com → Mail → Download MBOX

3. **Add API Keys** (Optional): Sign up for Clearbit and Hunter.io APIs for enhanced contact enrichment

4. **Contact Enrichment**: Use the "Enrich All Contacts" button to add social profiles and company data

## File Structure

```
crm-platform/
├── client/          # React frontend (built for production)
├── server/          # Node.js backend
├── package.json     # Root package file with deployment scripts
├── Procfile         # Process file for deployment
└── railway.json     # Railway configuration
```

Your CRM is production-ready! 🚀